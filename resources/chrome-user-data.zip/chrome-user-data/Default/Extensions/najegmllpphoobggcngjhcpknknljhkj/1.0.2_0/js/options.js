!function(e){if("object"==typeof exports)module.exports=e();else if("function"==typeof define&&define.amd)define(e);else{var n;"undefined"!=typeof window?n=window:"undefined"!=typeof global?n=global:"undefined"!=typeof self&&(n=self),(n.npc||(n.npc={})).exports=e()}}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(_dereq_,module,exports){
// Copyright (c) 2014 alelec. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

module.exports.keyCodeToChar = {8:"Backspace",9:"Tab",13:"Enter",16:"Shift",17:"Ctrl",18:"Alt",19:"Pause/Break",20:"Caps Lock",27:"Esc",32:"Space",33:"Page Up",34:"Page Down",35:"End",36:"Home",37:"Left",38:"Up",39:"Right",40:"Down",45:"Insert",46:"Delete",48:"0",49:"1",50:"2",51:"3",52:"4",53:"5",54:"6",55:"7",56:"8",57:"9",65:"A",66:"B",67:"C",68:"D",69:"E",70:"F",71:"G",72:"H",73:"I",74:"J",75:"K",76:"L",77:"M",78:"N",79:"O",80:"P",81:"Q",82:"R",83:"S",84:"T",85:"U",86:"V",87:"W",88:"X",89:"Y",90:"Z",91:"Windows",93:"Right Click",96:"Numpad 0",97:"Numpad 1",98:"Numpad 2",99:"Numpad 3",100:"Numpad 4",101:"Numpad 5",102:"Numpad 6",103:"Numpad 7",104:"Numpad 8",105:"Numpad 9",106:"Numpad *",107:"Numpad +",109:"Numpad -",110:"Numpad .",111:"Numpad /",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"Num Lock",145:"Scroll Lock",182:"My Computer",183:"My Calculator",186:";",187:"=",188:",",189:"-",190:".",191:"/",192:"`",219:"[",220:"\\",221:"]",222:"'"};
module.exports.keyCharToCode = {"Backspace":8,"Tab":9,"Enter":13,"Shift":16,"Ctrl":17,"Alt":18,"Pause/Break":19,"Caps Lock":20,"Esc":27,"Space":32,"Page Up":33,"Page Down":34,"End":35,"Home":36,"Left":37,"Up":38,"Right":39,"Down":40,"Insert":45,"Delete":46,"0":48,"1":49,"2":50,"3":51,"4":52,"5":53,"6":54,"7":55,"8":56,"9":57,"A":65,"B":66,"C":67,"D":68,"E":69,"F":70,"G":71,"H":72,"I":73,"J":74,"K":75,"L":76,"M":77,"N":78,"O":79,"P":80,"Q":81,"R":82,"S":83,"T":84,"U":85,"V":86,"W":87,"X":88,"Y":89,"Z":90,"Windows":91,"Right Click":93,"Numpad 0":96,"Numpad 1":97,"Numpad 2":98,"Numpad 3":99,"Numpad 4":100,"Numpad 5":101,"Numpad 6":102,"Numpad 7":103,"Numpad 8":104,"Numpad 9":105,"Numpad *":106,"Numpad +":107,"Numpad -":109,"Numpad .":110,"Numpad /":111,"F1":112,"F2":113,"F3":114,"F4":115,"F5":116,"F6":117,"F7":118,"F8":119,"F9":120,"F10":121,"F11":122,"F12":123,"Num Lock":144,"Scroll Lock":145,"My Computer":182,"My Calculator":183,";":186,"=":187,",":188,"-":189,".":190,"/":191,"`":192,"[":219,"\\":220,"]":221,"'":222};

defaultOptions = {
  hide_mouse : true,
  hide_mouse_delay : 1000
}
module.exports.defaultOptions = defaultOptions;

defaultActions = [
  { name: "Play/Pause",
    keys: [ "P",
              "Shift+P",
              "Ctrl+P",
              "Pause/Break" ],
  },
  { name: "Exit",
    keys: [ "Esc", 
              "Escape" ],
  },
  { name:"Volume Up",
    keys: [ "]" ],
  },
  { name: "Volume Down",
    keys: [ "[" ],
  },
  { name: "Reload",
    keys: [ "Enter", 
              "R" ],
  },
  { name: "Continue",
    keys: [ "Space", 
              "R" ],
  },
]
module.exports.defaultActions = defaultActions;

function storeActions(actions) {
  chrome.storage.local.set({"actions": actions});
}
module.exports.storeActions = storeActions;

module.exports.withActions = function(callback) {
  try {
    chrome.storage.local.get("actions", function(stored) {
      actions = stored["actions"];
      if (actions === undefined) {
        actions = defaultActions;
        storeActions(actions);
      }
      callback(actions);
    });
  } catch (e) { 
    actions = defaultActions;
    storeActions(actions);
  }
}


function storeOptions(options) {
  chrome.storage.local.set({"options": options});
}
module.exports.storeOptions = storeOptions;

module.exports.withOptions = function(callback) {
  try {
    chrome.storage.local.get("options", function(stored) {
      options = stored["options"];
      if (options === undefined) {
        options = defaultOptions;
        storeOptions(options);
      }
      callback(options);
    });
  } catch (e) { 
    options = defaultOptions;
    storeOptions(options);
  }
}

},{}],2:[function(_dereq_,module,exports){
;(function() {

// Copyright (c) 2014 alelec. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

common = _dereq_('./modules/common');

function Action(data) {
  var actions = document.getElementById('actions');
  this.node = document.getElementById('action-template').cloneNode(true);
  this.node.id = 'action' + (Action.next_id++);
  this.node.action = this;
  actions.appendChild(this.node);
  this.node.hidden = false;

  var next_keyId = 0;
  if (data) {
    this.getElement('action-label').innerHTML = data.name;

    keySelect = this.getElement('keySelect');
    for (var keycode in common.keyCodeToChar) {
      var opt = document.createElement('option');
      opt.value = common.keyCodeToChar[keycode];
      opt.innerHTML = common.keyCodeToChar[keycode];
      keySelect.appendChild(opt);
    }

    key = this.getElement('key');
    if (data.keys.length > 0) {
      for (idx = 0; idx < data.keys.length; ++idx) {
        keypress = data.keys[idx];
        if ((keypress !== null) && (keypress !== undefined)) {
          key_block = key.cloneNode(true);
          key_block.hidden = false;
          key_block.id = "key"+idx;
          keySelect = key_block.getElementsByClassName('keySelect')[0];

          keyParts = keypress.split('+');
          for (var kp_idx in keyParts) {
            kn = keyParts[kp_idx];
            if ((kn == "Shift") || (kn == "Alt") || (kn == "Ctrl")) {
              key_block.getElementsByClassName(kn)[0].checked = true;
            } else {
              keySelect.value = kn;
            }
          }
          keySelect.onchange = storeActions;
          ["Shift","Alt","Ctrl"].map(function(kn){key_block.getElementsByClassName(kn)[0].onchange = storeActions;})
          this.getElement('keys-col').appendChild(key_block);
        }
      }
    }
    next_keyId = data.keys.length;
  }

  this.render();

  this.getElement('enabled').onchange = storeActions;

  var action = this;
  this.getElement('move-up').onclick = function() {
    var sib = action.node.previousSibling;
    action.node.parentNode.removeChild(action.node);
    sib.parentNode.insertBefore(action.node, sib);
    storeActions();
  };
  this.getElement('move-down').onclick = function() {
    var parentNode = action.node.parentNode;
    var sib = action.node.nextSibling.nextSibling;
    parentNode.removeChild(action.node);
    if (sib) {
      parentNode.insertBefore(action.node, sib);
    } else {
      parentNode.appendChild(action.node);
    }
    storeActions();
  };
  this.getElement('AddKey').onclick = function() {
    // TODO
    key_block = key.cloneNode(true);
    key_block.hidden = false;
    key_block.id = "key"+next_keyId;
    next_keyId += 1;
    key_block.getElementsByClassName('keySelect')[0].onchange = storeActions;
    ["Shift","Alt","Ctrl"].map(function(kn){key_block.getElementsByClassName(kn)[0].onchange = storeActions;})
    keysCol = this.parentElement.parentElement.getElementsByClassName('keys-col')[0];
    keysCol.appendChild(key_block);
  };
  //storeActions();
}

Action.prototype.getElement = function(name) {
  return document.querySelector('#' + this.node.id + ' .' + name);
}

Action.prototype.render = function() {
  this.getElement('move-up').disabled = !this.node.previousSibling;
  this.getElement('move-down').disabled = !this.node.nextSibling;
}

Action.next_id = 0;

function setOptions(options) {
  var options_block = document.getElementById('options');
  hide_mouse = options_block.getElementsByClassName('hide-mouse')[0];
  hide_mouse_delay = options_block.getElementsByClassName('hide-mouse-delay')[0];

  hide_mouse.checked = options.hide_mouse;
  hide_mouse_delay.disabled = (!options.hide_mouse);
  hide_mouse_delay.value = options.hide_mouse_delay;

  hide_mouse.onchange = storeOptions;
  hide_mouse_delay.onchange = storeOptions;
}

function storeOptions() {
  options = {};
  options_block = document.getElementById('options');

  // Hide Mouse Settings
  hide_mouse = options_block.getElementsByClassName('hide-mouse')[0].checked;
  hide_mouse_delay = options_block.getElementsByClassName('hide-mouse-delay')[0];
  hide_mouse_delay.disabled = (!hide_mouse);

  options.hide_mouse = hide_mouse;
  options.hide_mouse_delay = hide_mouse_delay.value;

  // Store options
  common.storeOptions(options);
  //localStorage.options = JSON.stringify(options);
}

function storeActions() {
  
    actions = Array.prototype.slice.apply(
      document.getElementById('actions').childNodes).map(function(node) {
    node.action.render();
    var keysArr = [];
    selects = node.getElementsByClassName('keySelect');
    for (idx = 0; idx < selects.length; ++idx) {
      select = selects[idx]
      keyname = select.value;
      if (keyname != "RemoveKey") {
        ["Shift","Alt","Ctrl"].map(function(mod){
          if (select.parentNode.getElementsByClassName(mod)[0].checked) {
            keyname = mod + "+" + keyname;
          }
        });
        keysArr.push(keyname);
      }
    }
    options = {};
    options.name = node.action.getElement('action-label').innerHTML;
    options.keys = keysArr;
    return options
  });
  common.storeActions(actions);
}

window.onload = function() {
  common.withOptions(function(options) {
    setOptions(options);  
  });
  
  //actions = common.loadActions();
  common.withActions(function(actions) {
    var initialActions = []
    actions.forEach(function(action) {initialActions.push(new Action(action));})
    initialActions.map(function(action) {action.render();});
  });
  
}


})();


},{"./modules/common":1}]},{},[2])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2Nvcm9uYS9idHN5bmMvbmV0ZmxpeGJtYy9uZXRmbGl4LnBsYXllci5jb250cm9sbGVyX3F1aWNrL25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvaG9tZS9jb3JvbmEvYnRzeW5jL25ldGZsaXhibWMvbmV0ZmxpeC5wbGF5ZXIuY29udHJvbGxlcl9xdWljay9jb2RlL2pzL21vZHVsZXMvY29tbW9uLmpzIiwiL2hvbWUvY29yb25hL2J0c3luYy9uZXRmbGl4Ym1jL25ldGZsaXgucGxheWVyLmNvbnRyb2xsZXJfcXVpY2svY29kZS9qcy9vcHRpb25zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ25GQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt0aHJvdyBuZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpfXZhciBmPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChmLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGYsZi5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIvLyBDb3B5cmlnaHQgKGMpIDIwMTQgYWxlbGVjLiBBbGwgcmlnaHRzIHJlc2VydmVkLlxuLy8gVXNlIG9mIHRoaXMgc291cmNlIGNvZGUgaXMgZ292ZXJuZWQgYnkgYSBCU0Qtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZVxuLy8gZm91bmQgaW4gdGhlIExJQ0VOU0UgZmlsZS5cblxubW9kdWxlLmV4cG9ydHMua2V5Q29kZVRvQ2hhciA9IHs4OlwiQmFja3NwYWNlXCIsOTpcIlRhYlwiLDEzOlwiRW50ZXJcIiwxNjpcIlNoaWZ0XCIsMTc6XCJDdHJsXCIsMTg6XCJBbHRcIiwxOTpcIlBhdXNlL0JyZWFrXCIsMjA6XCJDYXBzIExvY2tcIiwyNzpcIkVzY1wiLDMyOlwiU3BhY2VcIiwzMzpcIlBhZ2UgVXBcIiwzNDpcIlBhZ2UgRG93blwiLDM1OlwiRW5kXCIsMzY6XCJIb21lXCIsMzc6XCJMZWZ0XCIsMzg6XCJVcFwiLDM5OlwiUmlnaHRcIiw0MDpcIkRvd25cIiw0NTpcIkluc2VydFwiLDQ2OlwiRGVsZXRlXCIsNDg6XCIwXCIsNDk6XCIxXCIsNTA6XCIyXCIsNTE6XCIzXCIsNTI6XCI0XCIsNTM6XCI1XCIsNTQ6XCI2XCIsNTU6XCI3XCIsNTY6XCI4XCIsNTc6XCI5XCIsNjU6XCJBXCIsNjY6XCJCXCIsNjc6XCJDXCIsNjg6XCJEXCIsNjk6XCJFXCIsNzA6XCJGXCIsNzE6XCJHXCIsNzI6XCJIXCIsNzM6XCJJXCIsNzQ6XCJKXCIsNzU6XCJLXCIsNzY6XCJMXCIsNzc6XCJNXCIsNzg6XCJOXCIsNzk6XCJPXCIsODA6XCJQXCIsODE6XCJRXCIsODI6XCJSXCIsODM6XCJTXCIsODQ6XCJUXCIsODU6XCJVXCIsODY6XCJWXCIsODc6XCJXXCIsODg6XCJYXCIsODk6XCJZXCIsOTA6XCJaXCIsOTE6XCJXaW5kb3dzXCIsOTM6XCJSaWdodCBDbGlja1wiLDk2OlwiTnVtcGFkIDBcIiw5NzpcIk51bXBhZCAxXCIsOTg6XCJOdW1wYWQgMlwiLDk5OlwiTnVtcGFkIDNcIiwxMDA6XCJOdW1wYWQgNFwiLDEwMTpcIk51bXBhZCA1XCIsMTAyOlwiTnVtcGFkIDZcIiwxMDM6XCJOdW1wYWQgN1wiLDEwNDpcIk51bXBhZCA4XCIsMTA1OlwiTnVtcGFkIDlcIiwxMDY6XCJOdW1wYWQgKlwiLDEwNzpcIk51bXBhZCArXCIsMTA5OlwiTnVtcGFkIC1cIiwxMTA6XCJOdW1wYWQgLlwiLDExMTpcIk51bXBhZCAvXCIsMTEyOlwiRjFcIiwxMTM6XCJGMlwiLDExNDpcIkYzXCIsMTE1OlwiRjRcIiwxMTY6XCJGNVwiLDExNzpcIkY2XCIsMTE4OlwiRjdcIiwxMTk6XCJGOFwiLDEyMDpcIkY5XCIsMTIxOlwiRjEwXCIsMTIyOlwiRjExXCIsMTIzOlwiRjEyXCIsMTQ0OlwiTnVtIExvY2tcIiwxNDU6XCJTY3JvbGwgTG9ja1wiLDE4MjpcIk15IENvbXB1dGVyXCIsMTgzOlwiTXkgQ2FsY3VsYXRvclwiLDE4NjpcIjtcIiwxODc6XCI9XCIsMTg4OlwiLFwiLDE4OTpcIi1cIiwxOTA6XCIuXCIsMTkxOlwiL1wiLDE5MjpcImBcIiwyMTk6XCJbXCIsMjIwOlwiXFxcXFwiLDIyMTpcIl1cIiwyMjI6XCInXCJ9O1xubW9kdWxlLmV4cG9ydHMua2V5Q2hhclRvQ29kZSA9IHtcIkJhY2tzcGFjZVwiOjgsXCJUYWJcIjo5LFwiRW50ZXJcIjoxMyxcIlNoaWZ0XCI6MTYsXCJDdHJsXCI6MTcsXCJBbHRcIjoxOCxcIlBhdXNlL0JyZWFrXCI6MTksXCJDYXBzIExvY2tcIjoyMCxcIkVzY1wiOjI3LFwiU3BhY2VcIjozMixcIlBhZ2UgVXBcIjozMyxcIlBhZ2UgRG93blwiOjM0LFwiRW5kXCI6MzUsXCJIb21lXCI6MzYsXCJMZWZ0XCI6MzcsXCJVcFwiOjM4LFwiUmlnaHRcIjozOSxcIkRvd25cIjo0MCxcIkluc2VydFwiOjQ1LFwiRGVsZXRlXCI6NDYsXCIwXCI6NDgsXCIxXCI6NDksXCIyXCI6NTAsXCIzXCI6NTEsXCI0XCI6NTIsXCI1XCI6NTMsXCI2XCI6NTQsXCI3XCI6NTUsXCI4XCI6NTYsXCI5XCI6NTcsXCJBXCI6NjUsXCJCXCI6NjYsXCJDXCI6NjcsXCJEXCI6NjgsXCJFXCI6NjksXCJGXCI6NzAsXCJHXCI6NzEsXCJIXCI6NzIsXCJJXCI6NzMsXCJKXCI6NzQsXCJLXCI6NzUsXCJMXCI6NzYsXCJNXCI6NzcsXCJOXCI6NzgsXCJPXCI6NzksXCJQXCI6ODAsXCJRXCI6ODEsXCJSXCI6ODIsXCJTXCI6ODMsXCJUXCI6ODQsXCJVXCI6ODUsXCJWXCI6ODYsXCJXXCI6ODcsXCJYXCI6ODgsXCJZXCI6ODksXCJaXCI6OTAsXCJXaW5kb3dzXCI6OTEsXCJSaWdodCBDbGlja1wiOjkzLFwiTnVtcGFkIDBcIjo5NixcIk51bXBhZCAxXCI6OTcsXCJOdW1wYWQgMlwiOjk4LFwiTnVtcGFkIDNcIjo5OSxcIk51bXBhZCA0XCI6MTAwLFwiTnVtcGFkIDVcIjoxMDEsXCJOdW1wYWQgNlwiOjEwMixcIk51bXBhZCA3XCI6MTAzLFwiTnVtcGFkIDhcIjoxMDQsXCJOdW1wYWQgOVwiOjEwNSxcIk51bXBhZCAqXCI6MTA2LFwiTnVtcGFkICtcIjoxMDcsXCJOdW1wYWQgLVwiOjEwOSxcIk51bXBhZCAuXCI6MTEwLFwiTnVtcGFkIC9cIjoxMTEsXCJGMVwiOjExMixcIkYyXCI6MTEzLFwiRjNcIjoxMTQsXCJGNFwiOjExNSxcIkY1XCI6MTE2LFwiRjZcIjoxMTcsXCJGN1wiOjExOCxcIkY4XCI6MTE5LFwiRjlcIjoxMjAsXCJGMTBcIjoxMjEsXCJGMTFcIjoxMjIsXCJGMTJcIjoxMjMsXCJOdW0gTG9ja1wiOjE0NCxcIlNjcm9sbCBMb2NrXCI6MTQ1LFwiTXkgQ29tcHV0ZXJcIjoxODIsXCJNeSBDYWxjdWxhdG9yXCI6MTgzLFwiO1wiOjE4NixcIj1cIjoxODcsXCIsXCI6MTg4LFwiLVwiOjE4OSxcIi5cIjoxOTAsXCIvXCI6MTkxLFwiYFwiOjE5MixcIltcIjoyMTksXCJcXFxcXCI6MjIwLFwiXVwiOjIyMSxcIidcIjoyMjJ9O1xuXG5kZWZhdWx0T3B0aW9ucyA9IHtcbiAgaGlkZV9tb3VzZSA6IHRydWUsXG4gIGhpZGVfbW91c2VfZGVsYXkgOiAxMDAwXG59XG5tb2R1bGUuZXhwb3J0cy5kZWZhdWx0T3B0aW9ucyA9IGRlZmF1bHRPcHRpb25zO1xuXG5kZWZhdWx0QWN0aW9ucyA9IFtcbiAgeyBuYW1lOiBcIlBsYXkvUGF1c2VcIixcbiAgICBrZXlzOiBbIFwiUFwiLFxuICAgICAgICAgICAgICBcIlNoaWZ0K1BcIixcbiAgICAgICAgICAgICAgXCJDdHJsK1BcIixcbiAgICAgICAgICAgICAgXCJQYXVzZS9CcmVha1wiIF0sXG4gIH0sXG4gIHsgbmFtZTogXCJFeGl0XCIsXG4gICAga2V5czogWyBcIkVzY1wiLCBcbiAgICAgICAgICAgICAgXCJFc2NhcGVcIiBdLFxuICB9LFxuICB7IG5hbWU6XCJWb2x1bWUgVXBcIixcbiAgICBrZXlzOiBbIFwiXVwiIF0sXG4gIH0sXG4gIHsgbmFtZTogXCJWb2x1bWUgRG93blwiLFxuICAgIGtleXM6IFsgXCJbXCIgXSxcbiAgfSxcbiAgeyBuYW1lOiBcIlJlbG9hZFwiLFxuICAgIGtleXM6IFsgXCJFbnRlclwiLCBcbiAgICAgICAgICAgICAgXCJSXCIgXSxcbiAgfSxcbiAgeyBuYW1lOiBcIkNvbnRpbnVlXCIsXG4gICAga2V5czogWyBcIlNwYWNlXCIsIFxuICAgICAgICAgICAgICBcIlJcIiBdLFxuICB9LFxuXVxubW9kdWxlLmV4cG9ydHMuZGVmYXVsdEFjdGlvbnMgPSBkZWZhdWx0QWN0aW9ucztcblxuZnVuY3Rpb24gc3RvcmVBY3Rpb25zKGFjdGlvbnMpIHtcbiAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcImFjdGlvbnNcIjogYWN0aW9uc30pO1xufVxubW9kdWxlLmV4cG9ydHMuc3RvcmVBY3Rpb25zID0gc3RvcmVBY3Rpb25zO1xuXG5tb2R1bGUuZXhwb3J0cy53aXRoQWN0aW9ucyA9IGZ1bmN0aW9uKGNhbGxiYWNrKSB7XG4gIHRyeSB7XG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFwiYWN0aW9uc1wiLCBmdW5jdGlvbihzdG9yZWQpIHtcbiAgICAgIGFjdGlvbnMgPSBzdG9yZWRbXCJhY3Rpb25zXCJdO1xuICAgICAgaWYgKGFjdGlvbnMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICBhY3Rpb25zID0gZGVmYXVsdEFjdGlvbnM7XG4gICAgICAgIHN0b3JlQWN0aW9ucyhhY3Rpb25zKTtcbiAgICAgIH1cbiAgICAgIGNhbGxiYWNrKGFjdGlvbnMpO1xuICAgIH0pO1xuICB9IGNhdGNoIChlKSB7IFxuICAgIGFjdGlvbnMgPSBkZWZhdWx0QWN0aW9ucztcbiAgICBzdG9yZUFjdGlvbnMoYWN0aW9ucyk7XG4gIH1cbn1cblxuXG5mdW5jdGlvbiBzdG9yZU9wdGlvbnMob3B0aW9ucykge1xuICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1wib3B0aW9uc1wiOiBvcHRpb25zfSk7XG59XG5tb2R1bGUuZXhwb3J0cy5zdG9yZU9wdGlvbnMgPSBzdG9yZU9wdGlvbnM7XG5cbm1vZHVsZS5leHBvcnRzLndpdGhPcHRpb25zID0gZnVuY3Rpb24oY2FsbGJhY2spIHtcbiAgdHJ5IHtcbiAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXCJvcHRpb25zXCIsIGZ1bmN0aW9uKHN0b3JlZCkge1xuICAgICAgb3B0aW9ucyA9IHN0b3JlZFtcIm9wdGlvbnNcIl07XG4gICAgICBpZiAob3B0aW9ucyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIG9wdGlvbnMgPSBkZWZhdWx0T3B0aW9ucztcbiAgICAgICAgc3RvcmVPcHRpb25zKG9wdGlvbnMpO1xuICAgICAgfVxuICAgICAgY2FsbGJhY2sob3B0aW9ucyk7XG4gICAgfSk7XG4gIH0gY2F0Y2ggKGUpIHsgXG4gICAgb3B0aW9ucyA9IGRlZmF1bHRPcHRpb25zO1xuICAgIHN0b3JlT3B0aW9ucyhvcHRpb25zKTtcbiAgfVxufVxuIiwiOyhmdW5jdGlvbigpIHtcblxuLy8gQ29weXJpZ2h0IChjKSAyMDE0IGFsZWxlYy4gQWxsIHJpZ2h0cyByZXNlcnZlZC5cbi8vIFVzZSBvZiB0aGlzIHNvdXJjZSBjb2RlIGlzIGdvdmVybmVkIGJ5IGEgQlNELXN0eWxlIGxpY2Vuc2UgdGhhdCBjYW4gYmVcbi8vIGZvdW5kIGluIHRoZSBMSUNFTlNFIGZpbGUuXG5cbmNvbW1vbiA9IHJlcXVpcmUoJy4vbW9kdWxlcy9jb21tb24nKTtcblxuZnVuY3Rpb24gQWN0aW9uKGRhdGEpIHtcbiAgdmFyIGFjdGlvbnMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYWN0aW9ucycpO1xuICB0aGlzLm5vZGUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYWN0aW9uLXRlbXBsYXRlJykuY2xvbmVOb2RlKHRydWUpO1xuICB0aGlzLm5vZGUuaWQgPSAnYWN0aW9uJyArIChBY3Rpb24ubmV4dF9pZCsrKTtcbiAgdGhpcy5ub2RlLmFjdGlvbiA9IHRoaXM7XG4gIGFjdGlvbnMuYXBwZW5kQ2hpbGQodGhpcy5ub2RlKTtcbiAgdGhpcy5ub2RlLmhpZGRlbiA9IGZhbHNlO1xuXG4gIHZhciBuZXh0X2tleUlkID0gMDtcbiAgaWYgKGRhdGEpIHtcbiAgICB0aGlzLmdldEVsZW1lbnQoJ2FjdGlvbi1sYWJlbCcpLmlubmVySFRNTCA9IGRhdGEubmFtZTtcblxuICAgIGtleVNlbGVjdCA9IHRoaXMuZ2V0RWxlbWVudCgna2V5U2VsZWN0Jyk7XG4gICAgZm9yICh2YXIga2V5Y29kZSBpbiBjb21tb24ua2V5Q29kZVRvQ2hhcikge1xuICAgICAgdmFyIG9wdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ29wdGlvbicpO1xuICAgICAgb3B0LnZhbHVlID0gY29tbW9uLmtleUNvZGVUb0NoYXJba2V5Y29kZV07XG4gICAgICBvcHQuaW5uZXJIVE1MID0gY29tbW9uLmtleUNvZGVUb0NoYXJba2V5Y29kZV07XG4gICAgICBrZXlTZWxlY3QuYXBwZW5kQ2hpbGQob3B0KTtcbiAgICB9XG5cbiAgICBrZXkgPSB0aGlzLmdldEVsZW1lbnQoJ2tleScpO1xuICAgIGlmIChkYXRhLmtleXMubGVuZ3RoID4gMCkge1xuICAgICAgZm9yIChpZHggPSAwOyBpZHggPCBkYXRhLmtleXMubGVuZ3RoOyArK2lkeCkge1xuICAgICAgICBrZXlwcmVzcyA9IGRhdGEua2V5c1tpZHhdO1xuICAgICAgICBpZiAoKGtleXByZXNzICE9PSBudWxsKSAmJiAoa2V5cHJlc3MgIT09IHVuZGVmaW5lZCkpIHtcbiAgICAgICAgICBrZXlfYmxvY2sgPSBrZXkuY2xvbmVOb2RlKHRydWUpO1xuICAgICAgICAgIGtleV9ibG9jay5oaWRkZW4gPSBmYWxzZTtcbiAgICAgICAgICBrZXlfYmxvY2suaWQgPSBcImtleVwiK2lkeDtcbiAgICAgICAgICBrZXlTZWxlY3QgPSBrZXlfYmxvY2suZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgna2V5U2VsZWN0JylbMF07XG5cbiAgICAgICAgICBrZXlQYXJ0cyA9IGtleXByZXNzLnNwbGl0KCcrJyk7XG4gICAgICAgICAgZm9yICh2YXIga3BfaWR4IGluIGtleVBhcnRzKSB7XG4gICAgICAgICAgICBrbiA9IGtleVBhcnRzW2twX2lkeF07XG4gICAgICAgICAgICBpZiAoKGtuID09IFwiU2hpZnRcIikgfHwgKGtuID09IFwiQWx0XCIpIHx8IChrbiA9PSBcIkN0cmxcIikpIHtcbiAgICAgICAgICAgICAga2V5X2Jsb2NrLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoa24pWzBdLmNoZWNrZWQgPSB0cnVlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAga2V5U2VsZWN0LnZhbHVlID0ga247XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGtleVNlbGVjdC5vbmNoYW5nZSA9IHN0b3JlQWN0aW9ucztcbiAgICAgICAgICBbXCJTaGlmdFwiLFwiQWx0XCIsXCJDdHJsXCJdLm1hcChmdW5jdGlvbihrbil7a2V5X2Jsb2NrLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoa24pWzBdLm9uY2hhbmdlID0gc3RvcmVBY3Rpb25zO30pXG4gICAgICAgICAgdGhpcy5nZXRFbGVtZW50KCdrZXlzLWNvbCcpLmFwcGVuZENoaWxkKGtleV9ibG9jayk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgbmV4dF9rZXlJZCA9IGRhdGEua2V5cy5sZW5ndGg7XG4gIH1cblxuICB0aGlzLnJlbmRlcigpO1xuXG4gIHRoaXMuZ2V0RWxlbWVudCgnZW5hYmxlZCcpLm9uY2hhbmdlID0gc3RvcmVBY3Rpb25zO1xuXG4gIHZhciBhY3Rpb24gPSB0aGlzO1xuICB0aGlzLmdldEVsZW1lbnQoJ21vdmUtdXAnKS5vbmNsaWNrID0gZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNpYiA9IGFjdGlvbi5ub2RlLnByZXZpb3VzU2libGluZztcbiAgICBhY3Rpb24ubm9kZS5wYXJlbnROb2RlLnJlbW92ZUNoaWxkKGFjdGlvbi5ub2RlKTtcbiAgICBzaWIucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoYWN0aW9uLm5vZGUsIHNpYik7XG4gICAgc3RvcmVBY3Rpb25zKCk7XG4gIH07XG4gIHRoaXMuZ2V0RWxlbWVudCgnbW92ZS1kb3duJykub25jbGljayA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciBwYXJlbnROb2RlID0gYWN0aW9uLm5vZGUucGFyZW50Tm9kZTtcbiAgICB2YXIgc2liID0gYWN0aW9uLm5vZGUubmV4dFNpYmxpbmcubmV4dFNpYmxpbmc7XG4gICAgcGFyZW50Tm9kZS5yZW1vdmVDaGlsZChhY3Rpb24ubm9kZSk7XG4gICAgaWYgKHNpYikge1xuICAgICAgcGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoYWN0aW9uLm5vZGUsIHNpYik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhcmVudE5vZGUuYXBwZW5kQ2hpbGQoYWN0aW9uLm5vZGUpO1xuICAgIH1cbiAgICBzdG9yZUFjdGlvbnMoKTtcbiAgfTtcbiAgdGhpcy5nZXRFbGVtZW50KCdBZGRLZXknKS5vbmNsaWNrID0gZnVuY3Rpb24oKSB7XG4gICAgLy8gVE9ET1xuICAgIGtleV9ibG9jayA9IGtleS5jbG9uZU5vZGUodHJ1ZSk7XG4gICAga2V5X2Jsb2NrLmhpZGRlbiA9IGZhbHNlO1xuICAgIGtleV9ibG9jay5pZCA9IFwia2V5XCIrbmV4dF9rZXlJZDtcbiAgICBuZXh0X2tleUlkICs9IDE7XG4gICAga2V5X2Jsb2NrLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2tleVNlbGVjdCcpWzBdLm9uY2hhbmdlID0gc3RvcmVBY3Rpb25zO1xuICAgIFtcIlNoaWZ0XCIsXCJBbHRcIixcIkN0cmxcIl0ubWFwKGZ1bmN0aW9uKGtuKXtrZXlfYmxvY2suZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShrbilbMF0ub25jaGFuZ2UgPSBzdG9yZUFjdGlvbnM7fSlcbiAgICBrZXlzQ29sID0gdGhpcy5wYXJlbnRFbGVtZW50LnBhcmVudEVsZW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgna2V5cy1jb2wnKVswXTtcbiAgICBrZXlzQ29sLmFwcGVuZENoaWxkKGtleV9ibG9jayk7XG4gIH07XG4gIC8vc3RvcmVBY3Rpb25zKCk7XG59XG5cbkFjdGlvbi5wcm90b3R5cGUuZ2V0RWxlbWVudCA9IGZ1bmN0aW9uKG5hbWUpIHtcbiAgcmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyMnICsgdGhpcy5ub2RlLmlkICsgJyAuJyArIG5hbWUpO1xufVxuXG5BY3Rpb24ucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uKCkge1xuICB0aGlzLmdldEVsZW1lbnQoJ21vdmUtdXAnKS5kaXNhYmxlZCA9ICF0aGlzLm5vZGUucHJldmlvdXNTaWJsaW5nO1xuICB0aGlzLmdldEVsZW1lbnQoJ21vdmUtZG93bicpLmRpc2FibGVkID0gIXRoaXMubm9kZS5uZXh0U2libGluZztcbn1cblxuQWN0aW9uLm5leHRfaWQgPSAwO1xuXG5mdW5jdGlvbiBzZXRPcHRpb25zKG9wdGlvbnMpIHtcbiAgdmFyIG9wdGlvbnNfYmxvY2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3B0aW9ucycpO1xuICBoaWRlX21vdXNlID0gb3B0aW9uc19ibG9jay5nZXRFbGVtZW50c0J5Q2xhc3NOYW1lKCdoaWRlLW1vdXNlJylbMF07XG4gIGhpZGVfbW91c2VfZGVsYXkgPSBvcHRpb25zX2Jsb2NrLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2hpZGUtbW91c2UtZGVsYXknKVswXTtcblxuICBoaWRlX21vdXNlLmNoZWNrZWQgPSBvcHRpb25zLmhpZGVfbW91c2U7XG4gIGhpZGVfbW91c2VfZGVsYXkuZGlzYWJsZWQgPSAoIW9wdGlvbnMuaGlkZV9tb3VzZSk7XG4gIGhpZGVfbW91c2VfZGVsYXkudmFsdWUgPSBvcHRpb25zLmhpZGVfbW91c2VfZGVsYXk7XG5cbiAgaGlkZV9tb3VzZS5vbmNoYW5nZSA9IHN0b3JlT3B0aW9ucztcbiAgaGlkZV9tb3VzZV9kZWxheS5vbmNoYW5nZSA9IHN0b3JlT3B0aW9ucztcbn1cblxuZnVuY3Rpb24gc3RvcmVPcHRpb25zKCkge1xuICBvcHRpb25zID0ge307XG4gIG9wdGlvbnNfYmxvY2sgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3B0aW9ucycpO1xuXG4gIC8vIEhpZGUgTW91c2UgU2V0dGluZ3NcbiAgaGlkZV9tb3VzZSA9IG9wdGlvbnNfYmxvY2suZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgnaGlkZS1tb3VzZScpWzBdLmNoZWNrZWQ7XG4gIGhpZGVfbW91c2VfZGVsYXkgPSBvcHRpb25zX2Jsb2NrLmdldEVsZW1lbnRzQnlDbGFzc05hbWUoJ2hpZGUtbW91c2UtZGVsYXknKVswXTtcbiAgaGlkZV9tb3VzZV9kZWxheS5kaXNhYmxlZCA9ICghaGlkZV9tb3VzZSk7XG5cbiAgb3B0aW9ucy5oaWRlX21vdXNlID0gaGlkZV9tb3VzZTtcbiAgb3B0aW9ucy5oaWRlX21vdXNlX2RlbGF5ID0gaGlkZV9tb3VzZV9kZWxheS52YWx1ZTtcblxuICAvLyBTdG9yZSBvcHRpb25zXG4gIGNvbW1vbi5zdG9yZU9wdGlvbnMob3B0aW9ucyk7XG4gIC8vbG9jYWxTdG9yYWdlLm9wdGlvbnMgPSBKU09OLnN0cmluZ2lmeShvcHRpb25zKTtcbn1cblxuZnVuY3Rpb24gc3RvcmVBY3Rpb25zKCkge1xuICBcbiAgICBhY3Rpb25zID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmFwcGx5KFxuICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FjdGlvbnMnKS5jaGlsZE5vZGVzKS5tYXAoZnVuY3Rpb24obm9kZSkge1xuICAgIG5vZGUuYWN0aW9uLnJlbmRlcigpO1xuICAgIHZhciBrZXlzQXJyID0gW107XG4gICAgc2VsZWN0cyA9IG5vZGUuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZSgna2V5U2VsZWN0Jyk7XG4gICAgZm9yIChpZHggPSAwOyBpZHggPCBzZWxlY3RzLmxlbmd0aDsgKytpZHgpIHtcbiAgICAgIHNlbGVjdCA9IHNlbGVjdHNbaWR4XVxuICAgICAga2V5bmFtZSA9IHNlbGVjdC52YWx1ZTtcbiAgICAgIGlmIChrZXluYW1lICE9IFwiUmVtb3ZlS2V5XCIpIHtcbiAgICAgICAgW1wiU2hpZnRcIixcIkFsdFwiLFwiQ3RybFwiXS5tYXAoZnVuY3Rpb24obW9kKXtcbiAgICAgICAgICBpZiAoc2VsZWN0LnBhcmVudE5vZGUuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShtb2QpWzBdLmNoZWNrZWQpIHtcbiAgICAgICAgICAgIGtleW5hbWUgPSBtb2QgKyBcIitcIiArIGtleW5hbWU7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAga2V5c0Fyci5wdXNoKGtleW5hbWUpO1xuICAgICAgfVxuICAgIH1cbiAgICBvcHRpb25zID0ge307XG4gICAgb3B0aW9ucy5uYW1lID0gbm9kZS5hY3Rpb24uZ2V0RWxlbWVudCgnYWN0aW9uLWxhYmVsJykuaW5uZXJIVE1MO1xuICAgIG9wdGlvbnMua2V5cyA9IGtleXNBcnI7XG4gICAgcmV0dXJuIG9wdGlvbnNcbiAgfSk7XG4gIGNvbW1vbi5zdG9yZUFjdGlvbnMoYWN0aW9ucyk7XG59XG5cbndpbmRvdy5vbmxvYWQgPSBmdW5jdGlvbigpIHtcbiAgY29tbW9uLndpdGhPcHRpb25zKGZ1bmN0aW9uKG9wdGlvbnMpIHtcbiAgICBzZXRPcHRpb25zKG9wdGlvbnMpOyAgXG4gIH0pO1xuICBcbiAgLy9hY3Rpb25zID0gY29tbW9uLmxvYWRBY3Rpb25zKCk7XG4gIGNvbW1vbi53aXRoQWN0aW9ucyhmdW5jdGlvbihhY3Rpb25zKSB7XG4gICAgdmFyIGluaXRpYWxBY3Rpb25zID0gW11cbiAgICBhY3Rpb25zLmZvckVhY2goZnVuY3Rpb24oYWN0aW9uKSB7aW5pdGlhbEFjdGlvbnMucHVzaChuZXcgQWN0aW9uKGFjdGlvbikpO30pXG4gICAgaW5pdGlhbEFjdGlvbnMubWFwKGZ1bmN0aW9uKGFjdGlvbikge2FjdGlvbi5yZW5kZXIoKTt9KTtcbiAgfSk7XG4gIFxufVxuXG5cbn0pKCk7XG5cbiJdfQ==
(2)
});
