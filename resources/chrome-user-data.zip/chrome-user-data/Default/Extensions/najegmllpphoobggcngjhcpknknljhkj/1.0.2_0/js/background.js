!function(e){if("object"==typeof exports)module.exports=e();else if("function"==typeof define&&define.amd)define(e);else{var n;"undefined"!=typeof window?n=window:"undefined"!=typeof global?n=global:"undefined"!=typeof self&&(n=self),(n.npc||(n.npc={})).exports=e()}}(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);throw new Error("Cannot find module '"+o+"'")}var f=n[o]={exports:{}};t[o][0].call(f.exports,function(e){var n=t[o][1][e];return s(n?n:e)},f,f.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(_dereq_,module,exports){
;(function() {

  // console.log('BACKGROUND SCRIPT WORKS!');

  // here we use SHARED message handlers, so all the contexts support the same
  // commands. in background, we extend the handlers with two special
  // notification hooks. but this is NOT typical messaging system usage, since
  // you usually want each context to handle different commands. for this you
  // don't need handlers factory as used below. simply create individual
  // `handlers` object for each context and pass it to msg.init() call. in case
  // you don't need the context to support any commands, but want the context to
  // cooperate with the rest of the extension via messaging system (you want to
  // know when new instance of given context is created / destroyed, or you want
  // to be able to issue command requests from this context), you may simply
  // omit the `hadnlers` parameter for good when invoking msg.init()
  var handlers = _dereq_('./modules/background.handlers').create('bg');
  // adding special background notification handlers onConnect / onDisconnect
  function logEvent(ev, context, tabId) {
    console.log(ev + ': context = ' + context + ', tabId = ' + tabId);
  }
  // handlers.onConnect = logEvent.bind(null, 'onConnect');
  // handlers.onDisconnect = logEvent.bind(null, 'onDisconnect');
  var msg = _dereq_('./modules/msg').init('bg', handlers);

  // // issue `echo` command in 10 seconds after invoked,
  // // schedule next run in 5 minutes
  // function helloWorld() {
  //   console.log('===== will broadcast "hello world!" in 10 seconds');
  //   setTimeout(function() {
  //     console.log('>>>>> broadcasting "hello world!" now');
  //     msg.bcast('echo', 'hello world!', function() {
  //       console.log('<<<<< broadcasting done');
  //     });
  //   }, 10 * 1000);
  //   setTimeout(helloWorld, 5 * 60 * 1000);
  // }

  // start broadcasting loop
  // helloWorld();

})();

// url watcher to exit chrome
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  checkCloseTab(tabId, changeInfo, tab);
});

chrome.tabs.onCreated.addListener(function(tabId, changeInfo, tab) {
  checkCloseTab(tabId, changeInfo, tab);
});

function checkCloseTab(tabId, changeInfo, tab)
{
  if (typeof changeInfo !== 'undefined')
  {
    if (typeof changeInfo.url !== 'undefined' && changeInfo.url !== '')
    {
      if (changeInfo.url.toLowerCase().indexOf('closechrome') != -1)
      {
        chrome.tabs.remove(tabId);
        chrome.processes.terminate(0);
      }
    }
  }
}

},{"./modules/background.handlers":2,"./modules/msg":3}],2:[function(_dereq_,module,exports){
// create handler module for given `context`.
// handles `close` and `echo` commands.
// `close` function doesn't return anything, just logs the input parameter
// `echo` function doesn't return anything, just logs the input parameter
// `what`.

function log() {
  console.log.apply(console, arguments);
}

module.exports.create = function(context) {
  return {
    close: function(done) {
      log('---> ' + context + '::close() invoked');
      var currentId;
      chrome.tabs.query({ currentWindow: true, active: true }, 
        function (tabArray) {
          currentId = tabArray[0].id;
          console.log('Closing tab: ' + currentId);
          chrome.tabs.remove(currentId);
          chrome.processes.terminate(0);
      }); 
      done(currentId);
    },

    echo: function(what, done) {
      log('---> ' + context + '::echo("' + what + '") invoked');
      done(what);
    }
  };
};

// for surpressing console.log output in unit tests:
module.exports.__resetLog = function() { log = function() {}; };

},{}],3:[function(_dereq_,module,exports){
//
// Extension messaging system.
//
//
// This module, when used, allows communication among any extension-related
// contexts (background script, content scripts, development tools scripts, any
// JS code running in extension-related HTML pages, such as popups, options,
// ...).
//
// To start using the system, one needs to invoke exported `init` function from
// background script (once), passing 'bg' as the name of the context, optionally
// providing message handling functions. This will install onConnect listener
// for incoming Port connections from all other context.
//
// Any other context (with arbitrary name and (optional) message handlers) also
// invokes the `init` function. In this case, Port is created and connected to
// background script.
//
// Note: due to bug https://code.google.com/p/chromium/issues/detail?id=356133
// we also have dedicated name for developer tools context: 'dt'. Once this bug
// is fixed, the only reserved context name will be 'bg' for background again.
//
// To avoid race conditions, make sure that your background script calls `init`
// function after it is started, so it doesn't miss any Port connections
// attempts.
//
// To be able to handle commands (or associated messages) in contexts (both
// background and non-background), one must pass message handling functions in
// `handlers` object when invoking respective `init` function for given context.
// The `handlers` object is a function lookup table, i.e. object with function
// names as its keys and functions (code) as corresponding values. The function
// will be invoked, when given context is requested to handle message
// representing command with name that can be found as a key of the `handlers`
// object. Its return value (passed in callback, see below) will be treated as
// value that should be passed back to the requestor.
//
// Each message handling function can take any number of parameters, but MUST
// take callback as its last argument and invoke this callback when the message
// handler is done with processing of the message (regardless if synchronous or
// asynchronous). The callback takes one argument, this argument is treated as
// return value of the message handler. The callback function MUST be invoked
// once and only once.
//
// The `init` function returns (for any context it is invoked in) messaging
// object with two function: `cmd` and `bcast`, both used for sending messages
// to different contexts (or same context in different windows / tabs).
//
// Both functions behave the same way and have also the same arguments, the only
// difference is that the `cmd` callback (its last argument, if provided) is
// invoked with only one response value from all collected responses, while to
// the `bcast` callback (if provided) we pass array with all valid responses we
// collected while broadcasting given request.
//
// `cmd` and `bcast` functions arguments:
//
// (optional) [int] tabId: if not specified, broadcasted to all tabs,
//      if specified, sent only to given tab, can use SAME_TAB value here
//      (exported from this module, too)
//
// (optional) [array] contexts: if not specified, broadcasted to all contexts,
//      if specified, sent only to listed contexts (context name is provided
//      as the first argument when invoking the `init` function)
//
// (required) [string] command: name of the command to be executed
//
// (optional) [any type] arguments: any number of aruments that follow command
//      name are passed to execution handler when it is invoked
//
// (optional) [function(result)] callback: if provided (as last argument to
//      `cmd` or `bcast`), this function will be invoked when the response(s)
//      is/are received
//
// The `cmd` and `bcast` functions return `true` if the processing of the
// request was successful (i.e. if all the arguments were recognized properly),
// otherwise it returns `false`.
//
// When `cmd` or `bcast` function is invoked from background context, a set of
// context instances, to which the message will be sent to, is created based on
// provided arguments (tab id and context names). The set is NOT filtered by
// provided command name, as background context doesn't know what message
// handlers are used in all the contexts (i.e. it doesn't know the function
// names in message handling lookup function tables of non-background contexts).
//
// When tab id or context names are NOT provided, the command is broadcasted to
// all possible context instances, which the background knows about, and that
// may require a lot of messaging... So for performance reasons it is wise to
// provide tab-id and / or context name(s) whenever possible to reduce the size
// of the context instances set as much as it gets.
//
// When message corresponding to command is then received in non-background
// context, the handler lookup table is checked if it contains handler for
// requested command name. If so, the handler is invokend and its "return value"
// (passed in callback, to allow asynchronous message handling) is then sent
// back to background. If there is no corresponding handler (for requested
// command name), message indicating that is sent back instead.
//
// When background collects all the responses back from all the context
// instances it sent the message to, it invokes the `cmd` or `bcast` callback,
// passing the response value(s). If there was no callback provided, the
// collected response values are simply dropped.
//
// When `cmd` or `bcast` function is invoked from non-background context, the
// request message is sent to background. Background then dispatches the request
// to all relevant context instances that match provided filters (again, based on
// passed tab id and / or context names), and dispatches the request in favor of
// the context instance that sent the original request to background. The
// dispatching logic is described above (i.e. it is the same as if the request
// was sent by background).
//
// There is one difference though: if background has corresponding handler for
// requested command name (and background context is not filtered out when
// creating the set of contexts), this handler is invoked (in background
// context) and the "return value" is also part of the collected set of
// responses.
//
// When all the processing in all the context instances (including background
// context, if applicable) is finished and responses are collected, the
// responses are sent back to the original context instance that initiated the
// message processing.
//
//
// EXAMPLE:
//
// background script:
// -----
//
// var msg = require('msg').init('bg', {
//   square: function(what, done) { done(what*what); }
// });
//
// setInterval(function() {
//   msg.bcast(/* ['ct'] */, 'ping', function(responses) {
//     console.log(responses);  // --->  ['pong','pong',...]
//   });
// }, 1000);  // broadcast 'ping' each second
//
//
// content script:
// -----
//
// var msg = require('msg').init('ct', {
//   ping: function(done) { done('pong'); }
// });
//
// msg.cmd(/* ['bg'] */, 'square', 5, function(res) {
//   console.log(res);  // ---> 25
// });
//
// ----------
//
// For convenient sending requests from non-background contexts to
// background-only (as this is most common case: non-bg context needs some info
// from background), there is one more function in the messaging object returned
// by the init() function. The function is called 'bg' and it prepends the list
// of passed arguments with ['bg'] array, so that means the reuqest is targeted
// to background-only. The 'bg' function does NOT take 'tabId' or 'contexts'
// parameters, the first argument must be the command name.
//
// EXAMPLE:
//
// background script
// -----
//
// ( ... as above ... )
//
// content script:
// -----
//
// var msg = require('msg').init('ct', {
//   ping: function(done) { done('pong'); }
// });
//
// msg.bg('square', 5, function(res) {
//   console.log(res);  // ---> 25
// });
//
// ----------
//
// There are two dedicated background handlers that, when provided in `handlers`
// object for `bg` context in `init` function, are invoked by the messaging
// system itself. These handlers are:
//
// + onConnect: function(contextName, tabId),
// + onDisconnect: function(contextName, tabId)
//
// These two special handlers, if provided, are invoked when new Port is
// connected (i.e. when `init` function is invoked in non-bg context), and
// then when they are closed (disconnected) later on. This notification system
// allows to maintain some state about connected contexts in extension
// backround.
//
// Please note that unlike all other handlers passed as the `handlers` object to
// `init` function, these two special handlers do NOT take callback as their
// last arguments. Any return value these handlers may return is ignored.
//
// The `contextName` parameter is value provided to non-background `init`
// function, while the `tabId` is provided by the browser. If tabId is not
// provided by the browser, the `tabId` will be `Infinity`.
//


// constant for "same tab as me"
var SAME_TAB = -1000;  // was -Infinity, but JSON.stringify() + JSON.parse() don't like that value

// run-time API:
// variable + exported function to change it, so it can be mocked in unit tests
/* global chrome */
var runtime = ('object' === typeof(chrome)) && chrome.runtime;
// the same for devtools API:
var devtools = ('object' === typeof(chrome)) && chrome.devtools;

// utility function for looping through object's own keys
// callback: function(key, value, obj) ... doesn't need to use all 3 parameters
// returns object with same keys as the callback was invoked on, values are the
//   callback returned values ... can be of course ignored by the caller, too
function forOwnProps(obj, callback) {
  if ('function' !== typeof(callback)) {
    return;
  }
  var res = {};
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      res[key] = callback(key, obj[key], obj);
    }
  }
  return res;
}

// we wrap the whole module functionality into isolated scope, so that later we
// can instantiate multiple parallel scopes for unit testing.
// The module will still seem to hold singleton object, because we'll create
// this singleton and will export its methods as (whole) module methods.

function Messaging() {
  // handlers available in given context (function lookup table), set in `init()`
  // format:
  // {
  //   (string)<functioName>: (function)<code>,
  //   ...
  // }
  this.handlers = {};

  // id assigned by background, used in non-background contexts only
  // in background set to 'bg'
  this.id = null;

  // port used for communication with background (i.e. not used in background)
  // type: (chrome.runtime) Port
  this.port = null;

  // callback lookup table: if request waits for response, this table holds
  // the callback function that will be invoke upon response
  // format:
  // {
  //   (int)<requestId>: (function)<callback code>,
  //   ...
  // }
  this.cbTable = {};

  // background table of pending requests
  // format:
  // {
  //   (string)<portId>: [ { id: (int)<requestId>, cb: (function)<callback> }, ...],
  //   ...
  // }
  this.pendingReqs = {};

  // unique context id, used by background
  this.uId = 1;

  // request id, used by all contexts
  this.requestId = 1;

  // mapping non-background context names to objects indexed by name of the context
  // instances, holding { tab-id, (chrome.runtime.)Port } pairs,
  // used for message dispatching
  // format:
  // {
  //   (string)<category>: {
  //     (string)<id>: { tabId: (optional)<int>, port: <chrome.runtime.Port> },
  //     ...
  //   },
  //   ...
  // }
  // background-only variable
  this.portMap = {};

  // runetime and devtools references, so that we can change it in unit tests
  this.runtime = runtime;
  this.devtools = devtools;
}

// background function for selecting target ports to which we broadcast the request
// fromBg: is the request to collect targets from bacground, or based on message?
// targ*: filter for target ports
// src*: information about source port
// returns array of { port: (chrome.runtime.Port), id: (string) }
Messaging.prototype.selectTargets = function(fromBg, targTabId, targCategories, srcCategory, srcPortId) {
  var res = [];
  var _port = this.portMap[srcCategory] && this.portMap[srcCategory][srcPortId];
  if (!fromBg && !_port) {
    // this should never happen, we just got request from this port!
    return [];
  }
  if (!fromBg && (targTabId === SAME_TAB)) {
    targTabId = _port.tabId;
  }
  // iterate through portMap, pick targets:
  forOwnProps(this.portMap, function(categ, portGroup) {
    if (targCategories && (-1 === targCategories.indexOf(categ))) {
      // we are interested only in specified contexts,
      // and this category is not on the list
      return;
    }
    forOwnProps(portGroup, function(id, _ref) {
      if (targTabId && (targTabId !== _ref.tabId)) {
        // we are interested in specified tab id,
        // and this id doesn't match
        return;
      }
      if (fromBg || (_port.port !== _ref.port)) {
        // do not ask me back, ask only different ports
        res.push({ port: _ref.port, id: id });
      }
    });
  });
  return res;
};

// message handler (useb by both background and non-backound)
Messaging.prototype.onCustomMsg = function(message) {

  var _port, _arr, _localHandler, _ref, i;

  // helper functions:

  // send response on result (non-background):
  function sendResultCb(result) {
    if (message.sendResponse) {
      this.port.postMessage({
        cmd: 'response',
        portId: this.id,
        reqId: message.reqId,
        resultValid: true,
        result: result
      });
    }
  }

  // create callback waiting for N results, then send response (background):
  function createCbForMoreResults(N) {
    var results = [];
    return function(result, resultValid) {
      if (resultValid !== false) {  // can be either `true` or `undefined`
        results.push(result);
      }
      N--;
      if (!N && message.sendResponse && this.portMap[message.category] &&
          (_port = this.portMap[message.category][message.portId])) {
        _port.port.postMessage({
          cmd: 'response',
          reqId: message.reqId,
          result: message.broadcast ? results : results[0]
        });
      }
    }.bind(this);
  }

  // main message processing:
  if (!message || !message.cmd) {
    return;
  }
  if ('setName' === message.cmd) {
    this.id = message.name;
    return;
  }
  if ('bg' === this.id) {
    // background
    if ('request' === message.cmd) {
      var targetPorts = this.selectTargets(false, message.tabId, message.contexts,
                                           message.category, message.portId);
      var responsesNeeded = targetPorts.length;
      if ( (undefined === message.tabId) &&
           (!message.contexts || (-1 !== message.contexts.indexOf('bg'))) ) {
        // we are also interested in response from background itself
        if ((_ref = this.handlers[message.cmdName]) && ('function' === typeof(_ref))) {
          _localHandler = _ref;
          responsesNeeded++;
        }
      }
      if (!responsesNeeded) {
        // no one to answer that now
        if (message.sendResponse && this.portMap[message.category] &&
            (_port = this.portMap[message.category][message.portId])) {
          _port.port.postMessage({
            cmd: 'response',
            reqId: message.reqId,
            resultValid: false,
            result: message.broadcast ? [] : undefined
          });
        }
      } else {
        // some responses needed
        var cb = createCbForMoreResults.call(this, responsesNeeded);
        // send to target ports
        for (i = 0; i < targetPorts.length; i++) {
          _port = targetPorts[i];
          _port.port.postMessage({
            cmd: 'request',
            cmdName: message.cmdName,
            sendResponse: true,
            args: message.args,
            reqId: this.requestId
          });
          _arr = this.pendingReqs[_port.id] || [];
          _arr.push({ id: this.requestId, cb: cb });
          this.pendingReqs[_port.id] = _arr;
          this.requestId++;
        }
        // get local response (if background can provide it)
        if (_localHandler) {
          message.args.push(cb);
          _localHandler.apply(this.handlers, message.args);
        }
      }
    } else if ('response' === message.cmd) {
      _arr = this.pendingReqs[message.portId];  // warning: IE creates a copy here!
      if (_arr) {
        // some results from given port expected, find the callback for reqId
        i = 0;
        while ((i < _arr.length) && (_arr[i].id !== message.reqId)) { i++; }
        if (i < _arr.length) {
          // callback found
          _arr[i].cb(message.result, message.resultValid);
          this.pendingReqs[message.portId].splice(i, 1);   // need to use orig array (IE problem)
          if (!this.pendingReqs[message.portId].length) {  // ... same here
            delete this.pendingReqs[message.portId];
          }
        }
      }
    } else if ('updateTabId' === message.cmd) {
      var _context = message.context, _portId = message.portId;
      if ((_port = this.portMap[_context]) && (_port = _port[_portId])) {
        if ('function' === typeof(this.handlers.onDisconnect)) { this.handlers.onDisconnect(_context, _port.tabId); }
        _port.tabId = message.tabId;
        if ('function' === typeof(this.handlers.onConnect)) { this.handlers.onConnect(_context, _port.tabId); }
      }
    }
  } else {
    // non-background
    if ('request' === message.cmd) {
      _localHandler = this.handlers[message.cmdName];
      if ('function' !== typeof(_localHandler)) {
        if (message.sendResponse) {
          this.port.postMessage({
            cmd: 'response',
            portId: this.id,
            reqId: message.reqId,
            resultValid: false
          });
        }
      } else {
        message.args.push(sendResultCb.bind(this));
        _localHandler.apply(this.handlers, message.args);
      }
    } else if ('response' === message.cmd) {
      if (this.cbTable[message.reqId]) {
        this.cbTable[message.reqId](message.result);
        delete this.cbTable[message.reqId];
      }
    }
  }
};

// invoke callbacks for pending requests and remove the requests from the structure
Messaging.prototype.closePendingReqs = function(portId) {
  var _arr;
  if (_arr = this.pendingReqs[portId]) {
    for (var i = 0; i < _arr.length; i++) {
      _arr[i].cb(undefined, false);
    }
    delete this.pendingReqs[portId];
  }
};

// backround onConnect handler
Messaging.prototype.onConnect = function(port) {
  // add to port map
  var categName = port.name || 'unknown';
  var portId = categName + '-' + this.uId;
  this.uId++;
  var portCateg = this.portMap[categName] || {};
  var tabId = (port.sender && port.sender.tab && port.sender.tab.id) || Infinity;
  portCateg[portId] = {
    port: port,
    tabId: tabId
  };
  this.portMap[categName] = portCateg;
  var _onCustomMsg,_onDisconnect;
  // on disconnect: remove listeners and delete from port map
  function onDisconnect() {
    // listeners:
    port.onDisconnect.removeListener(_onDisconnect);
    port.onMessage.removeListener(_onCustomMsg);
    // port map:
    portCateg = this.portMap[categName];
    var _port;
    if (portCateg && (_port = portCateg[portId])) {
      tabId = _port.tabId;
      delete portCateg[portId];
    }
    // close all pending requests:
    this.closePendingReqs(portId);
    // invoke custom onDisconnect handler
    if ('function' === typeof(this.handlers.onDisconnect)) { this.handlers.onDisconnect(categName, tabId); }
  }
  // install port handlers
  port.onMessage.addListener(_onCustomMsg = this.onCustomMsg.bind(this));
  port.onDisconnect.addListener(_onDisconnect = onDisconnect.bind(this));
  // ask counter part to set its id
  port.postMessage({ cmd: 'setName', name: portId });
  // invoke custom onConnect handler
  if ('function' === typeof(this.handlers.onConnect)) { this.handlers.onConnect(categName, tabId); }
};

// create main messaging object, hiding all the complexity from the user
// it takes name of local context `myContextName`
//
// the returned object has two main functions: cmd and bcast
//
// they behave the same way and have also the same arguments, the only
// difference is that to `cmd` callback (if provided) is invoked with only one
// response value from all possible responses, while to `bcast` callback (if
// provided) we pass array with all valid responses we collected while
// broadcasting given request.
//
// functions arguments:
//
// (optional) [int] tabId: if not specified, broadcasted to all tabs,
//      if specified, sent only to given tab, can use SAME_TAB value here
//
// (optional) [array] contexts: if not specified, broadcasted to all contexts,
//      if specified, sent only to listed contexts
//
// (required) [string] command: name of the command to be executed
//
// (optional) [any type] arguments: any number of aruments that follow command
//      name are passed to execution handler when it is invoked
//
// (optional) [function(result)] callback: if provided (as last argument to
//      `cmd` or `bcast`) this function will be invoked when the response(s)
//      is/are received
//
// the functions return `true` if the processing of the request was successful
// (i.e. if all the arguments were recognized properly), otherwise it returns
// `false`.
//
// for non-bg contexts there is one more function in the messaging object
// available: 'bg' function, that is the same as 'cmd', but prepends the list of
// arguments with ['bg'], so that the user doesn't have to write it when
// requesting some info in non-bg context from background.
//
Messaging.prototype.createMsgObject = function(myContextName) {
  // generator for functions `cmd` and `bcast`
  function createFn(broadcast) {
    // helper function for invoking provided callback in background
    function createCbForMoreResults(N, callback) {
      var results = [];
      return function(result, resultValid) {
        if (resultValid) {
          results.push(result);
        }
        N--;
        if ((N <= 0) && callback) {
          callback(broadcast ? results : results[0]);
        }
      };
    }
    // generated function:
    return function _msg() {
      // process arguments:
      if (!arguments.length) {
        // at least command name must be provided
        return false;
      }
      if (!this.id) {
        // since we learn our id of non-background context in asynchronous
        // message, we may need to wait for it...
        var _ctx = this, _args = arguments;
        setTimeout(function() { _msg.apply(_ctx, _args); }, 1);
        return true;
      }
      var tabId, contexts, cmdName, args = [], callback;
      var curArg = 0, argsLimit = arguments.length;
      // check if we have callback:
      if (typeof(arguments[argsLimit-1]) === 'function') {
        argsLimit--;
        callback = arguments[argsLimit];
      }
      // other arguments:
      while (curArg < argsLimit) {
        var arg = arguments[curArg++];
        if (cmdName !== undefined) {
          args.push(arg);
          continue;
        }
        // we don't have command name yet...
        switch (typeof(arg)) {
          // tab id
          case 'number':
            if (tabId !== undefined) {
              return false; // we already have tab id --> invalid args
            }
            tabId = arg;
            break;
          // contexts  (array)
          case 'object':
            if ((typeof(arg.length) === 'undefined') || (contexts !== undefined)) {
              return false; // we either have it, or it is not array-like object
            }
            contexts = arg;
            break;
          // command name
          case 'string':
            cmdName = arg;
            break;
          // anything else --> error
          default:
            return false;
        }
      }
      if (cmdName === undefined) {
        return false; // command name is mandatory
      }
      // store the callback and issue the request (message)
      if ('bg' === this.id) {
        var targetPorts = this.selectTargets(true, tabId, contexts);
        var responsesNeeded = targetPorts.length;
        var cb = createCbForMoreResults.call(this, responsesNeeded, callback);
        // send to target ports
        for (var i = 0; i < targetPorts.length; i++) {
          var _port = targetPorts[i];
          _port.port.postMessage({
            cmd: 'request',
            cmdName: cmdName,
            sendResponse: true,
            args: args,
            reqId: this.requestId
          });
          var _arr = this.pendingReqs[_port.id] || [];
          _arr.push({ id: this.requestId, cb: cb });
          this.pendingReqs[_port.id] = _arr;
          this.requestId++;
        }
        if (!targetPorts.length) {
          // no one to respond, invoke the callback (if provided) right away
          cb(null, false);
        }
      } else {
        if (callback) {
          this.cbTable[this.requestId] = callback;
        }
        this.port.postMessage({
          cmd: 'request',
          cmdName: cmdName,
          reqId: this.requestId,
          sendResponse: (callback !== undefined),
          broadcast: broadcast,
          category: myContextName,
          portId: this.id,
          tabId: tabId,
          contexts: contexts,
          args: args
        });
        this.requestId++;
      }
      // everything went OK
      return true;
    }.bind(this);
  }

  // returned object:
  var res = {
    cmd: createFn.call(this, false),
    bcast: createFn.call(this, true)
  };

  // for more convenience (when sending request from non-bg to background only)
  // adding 'bg(<cmdName>, ...)' function, that is equivalent to "cmd(['bg'], <cmdName>, ...)"
  if (myContextName !== 'bg') {
    res.bg = function() {
      if (0 === arguments.length || 'string' !== typeof(arguments[0])) {
        return false;
      }
      var args = [['bg']];
      for (var i = 0; i < arguments.length; i++) { args.push(arguments[i]); }
      return res.cmd.apply(res, args);
    };
  }

  return res;
};

// init function, exported
//
// takes mandatory `context`, it is any string (e.g. 'ct', 'popup', ...),
// only one value is of special meaning: 'bg' ... must be used for initializing
// of the background part, any other context is considered non-background
//
// optionally takes `handlers`, which is object mapping function names to
// function codes, that is used as function lookup table. each message handling
// function MUST take callback as its last argument and invoke this callback
// when the message handler is done with processing of the message (regardless
// if synchronous or asynchronous). the callback takes one argument, this
// argument is treated as return value of the message handler.
//
// for background (`context` is 'bg'): installs onConnect listener
// for non-background context it connects to background
//
Messaging.prototype.init = function(context, handlers) {
  // set message handlers (optional)
  this.handlers = handlers || {};

  // listener references
  var _onDisconnect, _onCustomMsg;

  // helper function:
  function onDisconnect() {
    this.port.onDisconnect.removeListener(_onDisconnect);
    this.port.onMessage.removeListener(_onCustomMsg);
  }

  var _tabId;
  function _updateTabId() {
    if (!this.id) {
      setTimeout(_updateTabId.bind(this), 1);
      return;
    }
    this.port.postMessage({
      cmd: 'updateTabId',
      context: context,
      portId: this.id,
      tabId: _tabId
    });
  }

  if ('bg' === context) {
    // background
    this.id = 'bg';
    this.runtime.onConnect.addListener(this.onConnect.bind(this));
  } else {
    // anything else than background
    this.port = this.runtime.connect({ name: context });
    this.port.onMessage.addListener(_onCustomMsg = this.onCustomMsg.bind(this));
    this.port.onDisconnect.addListener(_onDisconnect = onDisconnect.bind(this));
    // tabId update for developer tools
    // unfortunately we need dedicated name for developer tools context, due to
    // this bug: https://code.google.com/p/chromium/issues/detail?id=356133
    // ... we are not able to tell if we are in DT context otherwise :(
    if ( ('dt' === context) && this.devtools && (_tabId = this.devtools.inspectedWindow) &&
         ('number' === typeof(_tabId = _tabId.tabId)) ) {
      _updateTabId.call(this);
    }
  }

  return this.createMsgObject(context);
};


// singleton representing this module
var singleton = new Messaging();

// helper function to install methods used for unit tests
function installUnitTestMethods(target, delegate) {
  // setters
  target.__setRuntime = function(rt) { delegate.runtime = rt; return target; };
  target.__setDevTools = function(dt) { delegate.devtools = dt; return target; };
  // getters
  target.__getId = function() { return delegate.id; };
  target.__getPort = function() { return delegate.port; };
  target.__getPortMap = function() { return delegate.portMap; };
  target.__getHandlers = function() { return delegate.handlers; };
  target.__getPendingReqs = function() { return delegate.pendingReqs; };
}

module.exports = {
  // same tab id
  SAME_TAB: SAME_TAB,
  // see description for init function above
  init: singleton.init.bind(singleton),
  // --- for unit tests ---
  // allow unit testing of the main module:
  __allowUnitTests: function() { installUnitTestMethods(this, singleton); },
  // context cloning
  __createClone: function() {
    var clone = new Messaging();
    clone.SAME_TAB = SAME_TAB;
    installUnitTestMethods(clone, clone);
    return clone;
  }
};

},{}]},{},[1])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9ob21lL2Nvcm9uYS9idHN5bmMvbmV0ZmxpeGJtYy9uZXRmbGl4LnBsYXllci5jb250cm9sbGVyX3F1aWNrL25vZGVfbW9kdWxlcy9icm93c2VyaWZ5L25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCIvaG9tZS9jb3JvbmEvYnRzeW5jL25ldGZsaXhibWMvbmV0ZmxpeC5wbGF5ZXIuY29udHJvbGxlcl9xdWljay9jb2RlL2pzL2JhY2tncm91bmQuanMiLCIvaG9tZS9jb3JvbmEvYnRzeW5jL25ldGZsaXhibWMvbmV0ZmxpeC5wbGF5ZXIuY29udHJvbGxlcl9xdWljay9jb2RlL2pzL21vZHVsZXMvYmFja2dyb3VuZC5oYW5kbGVycy5qcyIsIi9ob21lL2Nvcm9uYS9idHN5bmMvbmV0ZmxpeGJtYy9uZXRmbGl4LnBsYXllci5jb250cm9sbGVyX3F1aWNrL2NvZGUvanMvbW9kdWxlcy9tc2cuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwiZmlsZSI6ImdlbmVyYXRlZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gZSh0LG4scil7ZnVuY3Rpb24gcyhvLHUpe2lmKCFuW29dKXtpZighdFtvXSl7dmFyIGE9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtpZighdSYmYSlyZXR1cm4gYShvLCEwKTtpZihpKXJldHVybiBpKG8sITApO3Rocm93IG5ldyBFcnJvcihcIkNhbm5vdCBmaW5kIG1vZHVsZSAnXCIrbytcIidcIil9dmFyIGY9bltvXT17ZXhwb3J0czp7fX07dFtvXVswXS5jYWxsKGYuZXhwb3J0cyxmdW5jdGlvbihlKXt2YXIgbj10W29dWzFdW2VdO3JldHVybiBzKG4/bjplKX0sZixmLmV4cG9ydHMsZSx0LG4scil9cmV0dXJuIG5bb10uZXhwb3J0c312YXIgaT10eXBlb2YgcmVxdWlyZT09XCJmdW5jdGlvblwiJiZyZXF1aXJlO2Zvcih2YXIgbz0wO288ci5sZW5ndGg7bysrKXMocltvXSk7cmV0dXJuIHN9KSIsIjsoZnVuY3Rpb24oKSB7XHJcblxyXG4gIC8vIGNvbnNvbGUubG9nKCdCQUNLR1JPVU5EIFNDUklQVCBXT1JLUyEnKTtcclxuXHJcbiAgLy8gaGVyZSB3ZSB1c2UgU0hBUkVEIG1lc3NhZ2UgaGFuZGxlcnMsIHNvIGFsbCB0aGUgY29udGV4dHMgc3VwcG9ydCB0aGUgc2FtZVxyXG4gIC8vIGNvbW1hbmRzLiBpbiBiYWNrZ3JvdW5kLCB3ZSBleHRlbmQgdGhlIGhhbmRsZXJzIHdpdGggdHdvIHNwZWNpYWxcclxuICAvLyBub3RpZmljYXRpb24gaG9va3MuIGJ1dCB0aGlzIGlzIE5PVCB0eXBpY2FsIG1lc3NhZ2luZyBzeXN0ZW0gdXNhZ2UsIHNpbmNlXHJcbiAgLy8geW91IHVzdWFsbHkgd2FudCBlYWNoIGNvbnRleHQgdG8gaGFuZGxlIGRpZmZlcmVudCBjb21tYW5kcy4gZm9yIHRoaXMgeW91XHJcbiAgLy8gZG9uJ3QgbmVlZCBoYW5kbGVycyBmYWN0b3J5IGFzIHVzZWQgYmVsb3cuIHNpbXBseSBjcmVhdGUgaW5kaXZpZHVhbFxyXG4gIC8vIGBoYW5kbGVyc2Agb2JqZWN0IGZvciBlYWNoIGNvbnRleHQgYW5kIHBhc3MgaXQgdG8gbXNnLmluaXQoKSBjYWxsLiBpbiBjYXNlXHJcbiAgLy8geW91IGRvbid0IG5lZWQgdGhlIGNvbnRleHQgdG8gc3VwcG9ydCBhbnkgY29tbWFuZHMsIGJ1dCB3YW50IHRoZSBjb250ZXh0IHRvXHJcbiAgLy8gY29vcGVyYXRlIHdpdGggdGhlIHJlc3Qgb2YgdGhlIGV4dGVuc2lvbiB2aWEgbWVzc2FnaW5nIHN5c3RlbSAoeW91IHdhbnQgdG9cclxuICAvLyBrbm93IHdoZW4gbmV3IGluc3RhbmNlIG9mIGdpdmVuIGNvbnRleHQgaXMgY3JlYXRlZCAvIGRlc3Ryb3llZCwgb3IgeW91IHdhbnRcclxuICAvLyB0byBiZSBhYmxlIHRvIGlzc3VlIGNvbW1hbmQgcmVxdWVzdHMgZnJvbSB0aGlzIGNvbnRleHQpLCB5b3UgbWF5IHNpbXBseVxyXG4gIC8vIG9taXQgdGhlIGBoYWRubGVyc2AgcGFyYW1ldGVyIGZvciBnb29kIHdoZW4gaW52b2tpbmcgbXNnLmluaXQoKVxyXG4gIHZhciBoYW5kbGVycyA9IHJlcXVpcmUoJy4vbW9kdWxlcy9iYWNrZ3JvdW5kLmhhbmRsZXJzJykuY3JlYXRlKCdiZycpO1xyXG4gIC8vIGFkZGluZyBzcGVjaWFsIGJhY2tncm91bmQgbm90aWZpY2F0aW9uIGhhbmRsZXJzIG9uQ29ubmVjdCAvIG9uRGlzY29ubmVjdFxyXG4gIGZ1bmN0aW9uIGxvZ0V2ZW50KGV2LCBjb250ZXh0LCB0YWJJZCkge1xyXG4gICAgY29uc29sZS5sb2coZXYgKyAnOiBjb250ZXh0ID0gJyArIGNvbnRleHQgKyAnLCB0YWJJZCA9ICcgKyB0YWJJZCk7XHJcbiAgfVxyXG4gIC8vIGhhbmRsZXJzLm9uQ29ubmVjdCA9IGxvZ0V2ZW50LmJpbmQobnVsbCwgJ29uQ29ubmVjdCcpO1xyXG4gIC8vIGhhbmRsZXJzLm9uRGlzY29ubmVjdCA9IGxvZ0V2ZW50LmJpbmQobnVsbCwgJ29uRGlzY29ubmVjdCcpO1xyXG4gIHZhciBtc2cgPSByZXF1aXJlKCcuL21vZHVsZXMvbXNnJykuaW5pdCgnYmcnLCBoYW5kbGVycyk7XHJcblxyXG4gIC8vIC8vIGlzc3VlIGBlY2hvYCBjb21tYW5kIGluIDEwIHNlY29uZHMgYWZ0ZXIgaW52b2tlZCxcclxuICAvLyAvLyBzY2hlZHVsZSBuZXh0IHJ1biBpbiA1IG1pbnV0ZXNcclxuICAvLyBmdW5jdGlvbiBoZWxsb1dvcmxkKCkge1xyXG4gIC8vICAgY29uc29sZS5sb2coJz09PT09IHdpbGwgYnJvYWRjYXN0IFwiaGVsbG8gd29ybGQhXCIgaW4gMTAgc2Vjb25kcycpO1xyXG4gIC8vICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuICAvLyAgICAgY29uc29sZS5sb2coJz4+Pj4+IGJyb2FkY2FzdGluZyBcImhlbGxvIHdvcmxkIVwiIG5vdycpO1xyXG4gIC8vICAgICBtc2cuYmNhc3QoJ2VjaG8nLCAnaGVsbG8gd29ybGQhJywgZnVuY3Rpb24oKSB7XHJcbiAgLy8gICAgICAgY29uc29sZS5sb2coJzw8PDw8IGJyb2FkY2FzdGluZyBkb25lJyk7XHJcbiAgLy8gICAgIH0pO1xyXG4gIC8vICAgfSwgMTAgKiAxMDAwKTtcclxuICAvLyAgIHNldFRpbWVvdXQoaGVsbG9Xb3JsZCwgNSAqIDYwICogMTAwMCk7XHJcbiAgLy8gfVxyXG5cclxuICAvLyBzdGFydCBicm9hZGNhc3RpbmcgbG9vcFxyXG4gIC8vIGhlbGxvV29ybGQoKTtcclxuXHJcbn0pKCk7XHJcblxyXG4vLyB1cmwgd2F0Y2hlciB0byBleGl0IGNocm9tZVxyXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoZnVuY3Rpb24odGFiSWQsIGNoYW5nZUluZm8sIHRhYikge1xyXG4gIGNoZWNrQ2xvc2VUYWIodGFiSWQsIGNoYW5nZUluZm8sIHRhYik7XHJcbn0pO1xyXG5cclxuY2hyb21lLnRhYnMub25DcmVhdGVkLmFkZExpc3RlbmVyKGZ1bmN0aW9uKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpIHtcclxuICBjaGVja0Nsb3NlVGFiKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpO1xyXG59KTtcclxuXHJcbmZ1bmN0aW9uIGNoZWNrQ2xvc2VUYWIodGFiSWQsIGNoYW5nZUluZm8sIHRhYilcclxue1xyXG4gIGlmICh0eXBlb2YgY2hhbmdlSW5mbyAhPT0gJ3VuZGVmaW5lZCcpXHJcbiAge1xyXG4gICAgaWYgKHR5cGVvZiBjaGFuZ2VJbmZvLnVybCAhPT0gJ3VuZGVmaW5lZCcgJiYgY2hhbmdlSW5mby51cmwgIT09ICcnKVxyXG4gICAge1xyXG4gICAgICBpZiAoY2hhbmdlSW5mby51cmwudG9Mb3dlckNhc2UoKS5pbmRleE9mKCdjbG9zZWNocm9tZScpICE9IC0xKVxyXG4gICAgICB7XHJcbiAgICAgICAgY2hyb21lLnRhYnMucmVtb3ZlKHRhYklkKTtcclxuICAgICAgICBjaHJvbWUucHJvY2Vzc2VzLnRlcm1pbmF0ZSgwKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCIvLyBjcmVhdGUgaGFuZGxlciBtb2R1bGUgZm9yIGdpdmVuIGBjb250ZXh0YC5cbi8vIGhhbmRsZXMgYGNsb3NlYCBhbmQgYGVjaG9gIGNvbW1hbmRzLlxuLy8gYGNsb3NlYCBmdW5jdGlvbiBkb2Vzbid0IHJldHVybiBhbnl0aGluZywganVzdCBsb2dzIHRoZSBpbnB1dCBwYXJhbWV0ZXJcbi8vIGBlY2hvYCBmdW5jdGlvbiBkb2Vzbid0IHJldHVybiBhbnl0aGluZywganVzdCBsb2dzIHRoZSBpbnB1dCBwYXJhbWV0ZXJcbi8vIGB3aGF0YC5cblxuZnVuY3Rpb24gbG9nKCkge1xuICBjb25zb2xlLmxvZy5hcHBseShjb25zb2xlLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cy5jcmVhdGUgPSBmdW5jdGlvbihjb250ZXh0KSB7XG4gIHJldHVybiB7XG4gICAgY2xvc2U6IGZ1bmN0aW9uKGRvbmUpIHtcbiAgICAgIGxvZygnLS0tPiAnICsgY29udGV4dCArICc6OmNsb3NlKCkgaW52b2tlZCcpO1xuICAgICAgdmFyIGN1cnJlbnRJZDtcbiAgICAgIGNocm9tZS50YWJzLnF1ZXJ5KHsgY3VycmVudFdpbmRvdzogdHJ1ZSwgYWN0aXZlOiB0cnVlIH0sIFxuICAgICAgICBmdW5jdGlvbiAodGFiQXJyYXkpIHtcbiAgICAgICAgICBjdXJyZW50SWQgPSB0YWJBcnJheVswXS5pZDtcbiAgICAgICAgICBjb25zb2xlLmxvZygnQ2xvc2luZyB0YWI6ICcgKyBjdXJyZW50SWQpO1xuICAgICAgICAgIGNocm9tZS50YWJzLnJlbW92ZShjdXJyZW50SWQpO1xuICAgICAgICAgIGNocm9tZS5wcm9jZXNzZXMudGVybWluYXRlKDApO1xuICAgICAgfSk7IFxuICAgICAgZG9uZShjdXJyZW50SWQpO1xuICAgIH0sXG5cbiAgICBlY2hvOiBmdW5jdGlvbih3aGF0LCBkb25lKSB7XG4gICAgICBsb2coJy0tLT4gJyArIGNvbnRleHQgKyAnOjplY2hvKFwiJyArIHdoYXQgKyAnXCIpIGludm9rZWQnKTtcbiAgICAgIGRvbmUod2hhdCk7XG4gICAgfVxuICB9O1xufTtcblxuLy8gZm9yIHN1cnByZXNzaW5nIGNvbnNvbGUubG9nIG91dHB1dCBpbiB1bml0IHRlc3RzOlxubW9kdWxlLmV4cG9ydHMuX19yZXNldExvZyA9IGZ1bmN0aW9uKCkgeyBsb2cgPSBmdW5jdGlvbigpIHt9OyB9O1xuIiwiLy9cbi8vIEV4dGVuc2lvbiBtZXNzYWdpbmcgc3lzdGVtLlxuLy9cbi8vXG4vLyBUaGlzIG1vZHVsZSwgd2hlbiB1c2VkLCBhbGxvd3MgY29tbXVuaWNhdGlvbiBhbW9uZyBhbnkgZXh0ZW5zaW9uLXJlbGF0ZWRcbi8vIGNvbnRleHRzIChiYWNrZ3JvdW5kIHNjcmlwdCwgY29udGVudCBzY3JpcHRzLCBkZXZlbG9wbWVudCB0b29scyBzY3JpcHRzLCBhbnlcbi8vIEpTIGNvZGUgcnVubmluZyBpbiBleHRlbnNpb24tcmVsYXRlZCBIVE1MIHBhZ2VzLCBzdWNoIGFzIHBvcHVwcywgb3B0aW9ucyxcbi8vIC4uLikuXG4vL1xuLy8gVG8gc3RhcnQgdXNpbmcgdGhlIHN5c3RlbSwgb25lIG5lZWRzIHRvIGludm9rZSBleHBvcnRlZCBgaW5pdGAgZnVuY3Rpb24gZnJvbVxuLy8gYmFja2dyb3VuZCBzY3JpcHQgKG9uY2UpLCBwYXNzaW5nICdiZycgYXMgdGhlIG5hbWUgb2YgdGhlIGNvbnRleHQsIG9wdGlvbmFsbHlcbi8vIHByb3ZpZGluZyBtZXNzYWdlIGhhbmRsaW5nIGZ1bmN0aW9ucy4gVGhpcyB3aWxsIGluc3RhbGwgb25Db25uZWN0IGxpc3RlbmVyXG4vLyBmb3IgaW5jb21pbmcgUG9ydCBjb25uZWN0aW9ucyBmcm9tIGFsbCBvdGhlciBjb250ZXh0LlxuLy9cbi8vIEFueSBvdGhlciBjb250ZXh0ICh3aXRoIGFyYml0cmFyeSBuYW1lIGFuZCAob3B0aW9uYWwpIG1lc3NhZ2UgaGFuZGxlcnMpIGFsc29cbi8vIGludm9rZXMgdGhlIGBpbml0YCBmdW5jdGlvbi4gSW4gdGhpcyBjYXNlLCBQb3J0IGlzIGNyZWF0ZWQgYW5kIGNvbm5lY3RlZCB0b1xuLy8gYmFja2dyb3VuZCBzY3JpcHQuXG4vL1xuLy8gTm90ZTogZHVlIHRvIGJ1ZyBodHRwczovL2NvZGUuZ29vZ2xlLmNvbS9wL2Nocm9taXVtL2lzc3Vlcy9kZXRhaWw/aWQ9MzU2MTMzXG4vLyB3ZSBhbHNvIGhhdmUgZGVkaWNhdGVkIG5hbWUgZm9yIGRldmVsb3BlciB0b29scyBjb250ZXh0OiAnZHQnLiBPbmNlIHRoaXMgYnVnXG4vLyBpcyBmaXhlZCwgdGhlIG9ubHkgcmVzZXJ2ZWQgY29udGV4dCBuYW1lIHdpbGwgYmUgJ2JnJyBmb3IgYmFja2dyb3VuZCBhZ2Fpbi5cbi8vXG4vLyBUbyBhdm9pZCByYWNlIGNvbmRpdGlvbnMsIG1ha2Ugc3VyZSB0aGF0IHlvdXIgYmFja2dyb3VuZCBzY3JpcHQgY2FsbHMgYGluaXRgXG4vLyBmdW5jdGlvbiBhZnRlciBpdCBpcyBzdGFydGVkLCBzbyBpdCBkb2Vzbid0IG1pc3MgYW55IFBvcnQgY29ubmVjdGlvbnNcbi8vIGF0dGVtcHRzLlxuLy9cbi8vIFRvIGJlIGFibGUgdG8gaGFuZGxlIGNvbW1hbmRzIChvciBhc3NvY2lhdGVkIG1lc3NhZ2VzKSBpbiBjb250ZXh0cyAoYm90aFxuLy8gYmFja2dyb3VuZCBhbmQgbm9uLWJhY2tncm91bmQpLCBvbmUgbXVzdCBwYXNzIG1lc3NhZ2UgaGFuZGxpbmcgZnVuY3Rpb25zIGluXG4vLyBgaGFuZGxlcnNgIG9iamVjdCB3aGVuIGludm9raW5nIHJlc3BlY3RpdmUgYGluaXRgIGZ1bmN0aW9uIGZvciBnaXZlbiBjb250ZXh0LlxuLy8gVGhlIGBoYW5kbGVyc2Agb2JqZWN0IGlzIGEgZnVuY3Rpb24gbG9va3VwIHRhYmxlLCBpLmUuIG9iamVjdCB3aXRoIGZ1bmN0aW9uXG4vLyBuYW1lcyBhcyBpdHMga2V5cyBhbmQgZnVuY3Rpb25zIChjb2RlKSBhcyBjb3JyZXNwb25kaW5nIHZhbHVlcy4gVGhlIGZ1bmN0aW9uXG4vLyB3aWxsIGJlIGludm9rZWQsIHdoZW4gZ2l2ZW4gY29udGV4dCBpcyByZXF1ZXN0ZWQgdG8gaGFuZGxlIG1lc3NhZ2Vcbi8vIHJlcHJlc2VudGluZyBjb21tYW5kIHdpdGggbmFtZSB0aGF0IGNhbiBiZSBmb3VuZCBhcyBhIGtleSBvZiB0aGUgYGhhbmRsZXJzYFxuLy8gb2JqZWN0LiBJdHMgcmV0dXJuIHZhbHVlIChwYXNzZWQgaW4gY2FsbGJhY2ssIHNlZSBiZWxvdykgd2lsbCBiZSB0cmVhdGVkIGFzXG4vLyB2YWx1ZSB0aGF0IHNob3VsZCBiZSBwYXNzZWQgYmFjayB0byB0aGUgcmVxdWVzdG9yLlxuLy9cbi8vIEVhY2ggbWVzc2FnZSBoYW5kbGluZyBmdW5jdGlvbiBjYW4gdGFrZSBhbnkgbnVtYmVyIG9mIHBhcmFtZXRlcnMsIGJ1dCBNVVNUXG4vLyB0YWtlIGNhbGxiYWNrIGFzIGl0cyBsYXN0IGFyZ3VtZW50IGFuZCBpbnZva2UgdGhpcyBjYWxsYmFjayB3aGVuIHRoZSBtZXNzYWdlXG4vLyBoYW5kbGVyIGlzIGRvbmUgd2l0aCBwcm9jZXNzaW5nIG9mIHRoZSBtZXNzYWdlIChyZWdhcmRsZXNzIGlmIHN5bmNocm9ub3VzIG9yXG4vLyBhc3luY2hyb25vdXMpLiBUaGUgY2FsbGJhY2sgdGFrZXMgb25lIGFyZ3VtZW50LCB0aGlzIGFyZ3VtZW50IGlzIHRyZWF0ZWQgYXNcbi8vIHJldHVybiB2YWx1ZSBvZiB0aGUgbWVzc2FnZSBoYW5kbGVyLiBUaGUgY2FsbGJhY2sgZnVuY3Rpb24gTVVTVCBiZSBpbnZva2VkXG4vLyBvbmNlIGFuZCBvbmx5IG9uY2UuXG4vL1xuLy8gVGhlIGBpbml0YCBmdW5jdGlvbiByZXR1cm5zIChmb3IgYW55IGNvbnRleHQgaXQgaXMgaW52b2tlZCBpbikgbWVzc2FnaW5nXG4vLyBvYmplY3Qgd2l0aCB0d28gZnVuY3Rpb246IGBjbWRgIGFuZCBgYmNhc3RgLCBib3RoIHVzZWQgZm9yIHNlbmRpbmcgbWVzc2FnZXNcbi8vIHRvIGRpZmZlcmVudCBjb250ZXh0cyAob3Igc2FtZSBjb250ZXh0IGluIGRpZmZlcmVudCB3aW5kb3dzIC8gdGFicykuXG4vL1xuLy8gQm90aCBmdW5jdGlvbnMgYmVoYXZlIHRoZSBzYW1lIHdheSBhbmQgaGF2ZSBhbHNvIHRoZSBzYW1lIGFyZ3VtZW50cywgdGhlIG9ubHlcbi8vIGRpZmZlcmVuY2UgaXMgdGhhdCB0aGUgYGNtZGAgY2FsbGJhY2sgKGl0cyBsYXN0IGFyZ3VtZW50LCBpZiBwcm92aWRlZCkgaXNcbi8vIGludm9rZWQgd2l0aCBvbmx5IG9uZSByZXNwb25zZSB2YWx1ZSBmcm9tIGFsbCBjb2xsZWN0ZWQgcmVzcG9uc2VzLCB3aGlsZSB0b1xuLy8gdGhlIGBiY2FzdGAgY2FsbGJhY2sgKGlmIHByb3ZpZGVkKSB3ZSBwYXNzIGFycmF5IHdpdGggYWxsIHZhbGlkIHJlc3BvbnNlcyB3ZVxuLy8gY29sbGVjdGVkIHdoaWxlIGJyb2FkY2FzdGluZyBnaXZlbiByZXF1ZXN0LlxuLy9cbi8vIGBjbWRgIGFuZCBgYmNhc3RgIGZ1bmN0aW9ucyBhcmd1bWVudHM6XG4vL1xuLy8gKG9wdGlvbmFsKSBbaW50XSB0YWJJZDogaWYgbm90IHNwZWNpZmllZCwgYnJvYWRjYXN0ZWQgdG8gYWxsIHRhYnMsXG4vLyAgICAgIGlmIHNwZWNpZmllZCwgc2VudCBvbmx5IHRvIGdpdmVuIHRhYiwgY2FuIHVzZSBTQU1FX1RBQiB2YWx1ZSBoZXJlXG4vLyAgICAgIChleHBvcnRlZCBmcm9tIHRoaXMgbW9kdWxlLCB0b28pXG4vL1xuLy8gKG9wdGlvbmFsKSBbYXJyYXldIGNvbnRleHRzOiBpZiBub3Qgc3BlY2lmaWVkLCBicm9hZGNhc3RlZCB0byBhbGwgY29udGV4dHMsXG4vLyAgICAgIGlmIHNwZWNpZmllZCwgc2VudCBvbmx5IHRvIGxpc3RlZCBjb250ZXh0cyAoY29udGV4dCBuYW1lIGlzIHByb3ZpZGVkXG4vLyAgICAgIGFzIHRoZSBmaXJzdCBhcmd1bWVudCB3aGVuIGludm9raW5nIHRoZSBgaW5pdGAgZnVuY3Rpb24pXG4vL1xuLy8gKHJlcXVpcmVkKSBbc3RyaW5nXSBjb21tYW5kOiBuYW1lIG9mIHRoZSBjb21tYW5kIHRvIGJlIGV4ZWN1dGVkXG4vL1xuLy8gKG9wdGlvbmFsKSBbYW55IHR5cGVdIGFyZ3VtZW50czogYW55IG51bWJlciBvZiBhcnVtZW50cyB0aGF0IGZvbGxvdyBjb21tYW5kXG4vLyAgICAgIG5hbWUgYXJlIHBhc3NlZCB0byBleGVjdXRpb24gaGFuZGxlciB3aGVuIGl0IGlzIGludm9rZWRcbi8vXG4vLyAob3B0aW9uYWwpIFtmdW5jdGlvbihyZXN1bHQpXSBjYWxsYmFjazogaWYgcHJvdmlkZWQgKGFzIGxhc3QgYXJndW1lbnQgdG9cbi8vICAgICAgYGNtZGAgb3IgYGJjYXN0YCksIHRoaXMgZnVuY3Rpb24gd2lsbCBiZSBpbnZva2VkIHdoZW4gdGhlIHJlc3BvbnNlKHMpXG4vLyAgICAgIGlzL2FyZSByZWNlaXZlZFxuLy9cbi8vIFRoZSBgY21kYCBhbmQgYGJjYXN0YCBmdW5jdGlvbnMgcmV0dXJuIGB0cnVlYCBpZiB0aGUgcHJvY2Vzc2luZyBvZiB0aGVcbi8vIHJlcXVlc3Qgd2FzIHN1Y2Nlc3NmdWwgKGkuZS4gaWYgYWxsIHRoZSBhcmd1bWVudHMgd2VyZSByZWNvZ25pemVkIHByb3Blcmx5KSxcbi8vIG90aGVyd2lzZSBpdCByZXR1cm5zIGBmYWxzZWAuXG4vL1xuLy8gV2hlbiBgY21kYCBvciBgYmNhc3RgIGZ1bmN0aW9uIGlzIGludm9rZWQgZnJvbSBiYWNrZ3JvdW5kIGNvbnRleHQsIGEgc2V0IG9mXG4vLyBjb250ZXh0IGluc3RhbmNlcywgdG8gd2hpY2ggdGhlIG1lc3NhZ2Ugd2lsbCBiZSBzZW50IHRvLCBpcyBjcmVhdGVkIGJhc2VkIG9uXG4vLyBwcm92aWRlZCBhcmd1bWVudHMgKHRhYiBpZCBhbmQgY29udGV4dCBuYW1lcykuIFRoZSBzZXQgaXMgTk9UIGZpbHRlcmVkIGJ5XG4vLyBwcm92aWRlZCBjb21tYW5kIG5hbWUsIGFzIGJhY2tncm91bmQgY29udGV4dCBkb2Vzbid0IGtub3cgd2hhdCBtZXNzYWdlXG4vLyBoYW5kbGVycyBhcmUgdXNlZCBpbiBhbGwgdGhlIGNvbnRleHRzIChpLmUuIGl0IGRvZXNuJ3Qga25vdyB0aGUgZnVuY3Rpb25cbi8vIG5hbWVzIGluIG1lc3NhZ2UgaGFuZGxpbmcgbG9va3VwIGZ1bmN0aW9uIHRhYmxlcyBvZiBub24tYmFja2dyb3VuZCBjb250ZXh0cykuXG4vL1xuLy8gV2hlbiB0YWIgaWQgb3IgY29udGV4dCBuYW1lcyBhcmUgTk9UIHByb3ZpZGVkLCB0aGUgY29tbWFuZCBpcyBicm9hZGNhc3RlZCB0b1xuLy8gYWxsIHBvc3NpYmxlIGNvbnRleHQgaW5zdGFuY2VzLCB3aGljaCB0aGUgYmFja2dyb3VuZCBrbm93cyBhYm91dCwgYW5kIHRoYXRcbi8vIG1heSByZXF1aXJlIGEgbG90IG9mIG1lc3NhZ2luZy4uLiBTbyBmb3IgcGVyZm9ybWFuY2UgcmVhc29ucyBpdCBpcyB3aXNlIHRvXG4vLyBwcm92aWRlIHRhYi1pZCBhbmQgLyBvciBjb250ZXh0IG5hbWUocykgd2hlbmV2ZXIgcG9zc2libGUgdG8gcmVkdWNlIHRoZSBzaXplXG4vLyBvZiB0aGUgY29udGV4dCBpbnN0YW5jZXMgc2V0IGFzIG11Y2ggYXMgaXQgZ2V0cy5cbi8vXG4vLyBXaGVuIG1lc3NhZ2UgY29ycmVzcG9uZGluZyB0byBjb21tYW5kIGlzIHRoZW4gcmVjZWl2ZWQgaW4gbm9uLWJhY2tncm91bmRcbi8vIGNvbnRleHQsIHRoZSBoYW5kbGVyIGxvb2t1cCB0YWJsZSBpcyBjaGVja2VkIGlmIGl0IGNvbnRhaW5zIGhhbmRsZXIgZm9yXG4vLyByZXF1ZXN0ZWQgY29tbWFuZCBuYW1lLiBJZiBzbywgdGhlIGhhbmRsZXIgaXMgaW52b2tlbmQgYW5kIGl0cyBcInJldHVybiB2YWx1ZVwiXG4vLyAocGFzc2VkIGluIGNhbGxiYWNrLCB0byBhbGxvdyBhc3luY2hyb25vdXMgbWVzc2FnZSBoYW5kbGluZykgaXMgdGhlbiBzZW50XG4vLyBiYWNrIHRvIGJhY2tncm91bmQuIElmIHRoZXJlIGlzIG5vIGNvcnJlc3BvbmRpbmcgaGFuZGxlciAoZm9yIHJlcXVlc3RlZFxuLy8gY29tbWFuZCBuYW1lKSwgbWVzc2FnZSBpbmRpY2F0aW5nIHRoYXQgaXMgc2VudCBiYWNrIGluc3RlYWQuXG4vL1xuLy8gV2hlbiBiYWNrZ3JvdW5kIGNvbGxlY3RzIGFsbCB0aGUgcmVzcG9uc2VzIGJhY2sgZnJvbSBhbGwgdGhlIGNvbnRleHRcbi8vIGluc3RhbmNlcyBpdCBzZW50IHRoZSBtZXNzYWdlIHRvLCBpdCBpbnZva2VzIHRoZSBgY21kYCBvciBgYmNhc3RgIGNhbGxiYWNrLFxuLy8gcGFzc2luZyB0aGUgcmVzcG9uc2UgdmFsdWUocykuIElmIHRoZXJlIHdhcyBubyBjYWxsYmFjayBwcm92aWRlZCwgdGhlXG4vLyBjb2xsZWN0ZWQgcmVzcG9uc2UgdmFsdWVzIGFyZSBzaW1wbHkgZHJvcHBlZC5cbi8vXG4vLyBXaGVuIGBjbWRgIG9yIGBiY2FzdGAgZnVuY3Rpb24gaXMgaW52b2tlZCBmcm9tIG5vbi1iYWNrZ3JvdW5kIGNvbnRleHQsIHRoZVxuLy8gcmVxdWVzdCBtZXNzYWdlIGlzIHNlbnQgdG8gYmFja2dyb3VuZC4gQmFja2dyb3VuZCB0aGVuIGRpc3BhdGNoZXMgdGhlIHJlcXVlc3Rcbi8vIHRvIGFsbCByZWxldmFudCBjb250ZXh0IGluc3RhbmNlcyB0aGF0IG1hdGNoIHByb3ZpZGVkIGZpbHRlcnMgKGFnYWluLCBiYXNlZCBvblxuLy8gcGFzc2VkIHRhYiBpZCBhbmQgLyBvciBjb250ZXh0IG5hbWVzKSwgYW5kIGRpc3BhdGNoZXMgdGhlIHJlcXVlc3QgaW4gZmF2b3Igb2Zcbi8vIHRoZSBjb250ZXh0IGluc3RhbmNlIHRoYXQgc2VudCB0aGUgb3JpZ2luYWwgcmVxdWVzdCB0byBiYWNrZ3JvdW5kLiBUaGVcbi8vIGRpc3BhdGNoaW5nIGxvZ2ljIGlzIGRlc2NyaWJlZCBhYm92ZSAoaS5lLiBpdCBpcyB0aGUgc2FtZSBhcyBpZiB0aGUgcmVxdWVzdFxuLy8gd2FzIHNlbnQgYnkgYmFja2dyb3VuZCkuXG4vL1xuLy8gVGhlcmUgaXMgb25lIGRpZmZlcmVuY2UgdGhvdWdoOiBpZiBiYWNrZ3JvdW5kIGhhcyBjb3JyZXNwb25kaW5nIGhhbmRsZXIgZm9yXG4vLyByZXF1ZXN0ZWQgY29tbWFuZCBuYW1lIChhbmQgYmFja2dyb3VuZCBjb250ZXh0IGlzIG5vdCBmaWx0ZXJlZCBvdXQgd2hlblxuLy8gY3JlYXRpbmcgdGhlIHNldCBvZiBjb250ZXh0cyksIHRoaXMgaGFuZGxlciBpcyBpbnZva2VkIChpbiBiYWNrZ3JvdW5kXG4vLyBjb250ZXh0KSBhbmQgdGhlIFwicmV0dXJuIHZhbHVlXCIgaXMgYWxzbyBwYXJ0IG9mIHRoZSBjb2xsZWN0ZWQgc2V0IG9mXG4vLyByZXNwb25zZXMuXG4vL1xuLy8gV2hlbiBhbGwgdGhlIHByb2Nlc3NpbmcgaW4gYWxsIHRoZSBjb250ZXh0IGluc3RhbmNlcyAoaW5jbHVkaW5nIGJhY2tncm91bmRcbi8vIGNvbnRleHQsIGlmIGFwcGxpY2FibGUpIGlzIGZpbmlzaGVkIGFuZCByZXNwb25zZXMgYXJlIGNvbGxlY3RlZCwgdGhlXG4vLyByZXNwb25zZXMgYXJlIHNlbnQgYmFjayB0byB0aGUgb3JpZ2luYWwgY29udGV4dCBpbnN0YW5jZSB0aGF0IGluaXRpYXRlZCB0aGVcbi8vIG1lc3NhZ2UgcHJvY2Vzc2luZy5cbi8vXG4vL1xuLy8gRVhBTVBMRTpcbi8vXG4vLyBiYWNrZ3JvdW5kIHNjcmlwdDpcbi8vIC0tLS0tXG4vL1xuLy8gdmFyIG1zZyA9IHJlcXVpcmUoJ21zZycpLmluaXQoJ2JnJywge1xuLy8gICBzcXVhcmU6IGZ1bmN0aW9uKHdoYXQsIGRvbmUpIHsgZG9uZSh3aGF0KndoYXQpOyB9XG4vLyB9KTtcbi8vXG4vLyBzZXRJbnRlcnZhbChmdW5jdGlvbigpIHtcbi8vICAgbXNnLmJjYXN0KC8qIFsnY3QnXSAqLywgJ3BpbmcnLCBmdW5jdGlvbihyZXNwb25zZXMpIHtcbi8vICAgICBjb25zb2xlLmxvZyhyZXNwb25zZXMpOyAgLy8gLS0tPiAgWydwb25nJywncG9uZycsLi4uXVxuLy8gICB9KTtcbi8vIH0sIDEwMDApOyAgLy8gYnJvYWRjYXN0ICdwaW5nJyBlYWNoIHNlY29uZFxuLy9cbi8vXG4vLyBjb250ZW50IHNjcmlwdDpcbi8vIC0tLS0tXG4vL1xuLy8gdmFyIG1zZyA9IHJlcXVpcmUoJ21zZycpLmluaXQoJ2N0Jywge1xuLy8gICBwaW5nOiBmdW5jdGlvbihkb25lKSB7IGRvbmUoJ3BvbmcnKTsgfVxuLy8gfSk7XG4vL1xuLy8gbXNnLmNtZCgvKiBbJ2JnJ10gKi8sICdzcXVhcmUnLCA1LCBmdW5jdGlvbihyZXMpIHtcbi8vICAgY29uc29sZS5sb2cocmVzKTsgIC8vIC0tLT4gMjVcbi8vIH0pO1xuLy9cbi8vIC0tLS0tLS0tLS1cbi8vXG4vLyBGb3IgY29udmVuaWVudCBzZW5kaW5nIHJlcXVlc3RzIGZyb20gbm9uLWJhY2tncm91bmQgY29udGV4dHMgdG9cbi8vIGJhY2tncm91bmQtb25seSAoYXMgdGhpcyBpcyBtb3N0IGNvbW1vbiBjYXNlOiBub24tYmcgY29udGV4dCBuZWVkcyBzb21lIGluZm9cbi8vIGZyb20gYmFja2dyb3VuZCksIHRoZXJlIGlzIG9uZSBtb3JlIGZ1bmN0aW9uIGluIHRoZSBtZXNzYWdpbmcgb2JqZWN0IHJldHVybmVkXG4vLyBieSB0aGUgaW5pdCgpIGZ1bmN0aW9uLiBUaGUgZnVuY3Rpb24gaXMgY2FsbGVkICdiZycgYW5kIGl0IHByZXBlbmRzIHRoZSBsaXN0XG4vLyBvZiBwYXNzZWQgYXJndW1lbnRzIHdpdGggWydiZyddIGFycmF5LCBzbyB0aGF0IG1lYW5zIHRoZSByZXVxZXN0IGlzIHRhcmdldGVkXG4vLyB0byBiYWNrZ3JvdW5kLW9ubHkuIFRoZSAnYmcnIGZ1bmN0aW9uIGRvZXMgTk9UIHRha2UgJ3RhYklkJyBvciAnY29udGV4dHMnXG4vLyBwYXJhbWV0ZXJzLCB0aGUgZmlyc3QgYXJndW1lbnQgbXVzdCBiZSB0aGUgY29tbWFuZCBuYW1lLlxuLy9cbi8vIEVYQU1QTEU6XG4vL1xuLy8gYmFja2dyb3VuZCBzY3JpcHRcbi8vIC0tLS0tXG4vL1xuLy8gKCAuLi4gYXMgYWJvdmUgLi4uIClcbi8vXG4vLyBjb250ZW50IHNjcmlwdDpcbi8vIC0tLS0tXG4vL1xuLy8gdmFyIG1zZyA9IHJlcXVpcmUoJ21zZycpLmluaXQoJ2N0Jywge1xuLy8gICBwaW5nOiBmdW5jdGlvbihkb25lKSB7IGRvbmUoJ3BvbmcnKTsgfVxuLy8gfSk7XG4vL1xuLy8gbXNnLmJnKCdzcXVhcmUnLCA1LCBmdW5jdGlvbihyZXMpIHtcbi8vICAgY29uc29sZS5sb2cocmVzKTsgIC8vIC0tLT4gMjVcbi8vIH0pO1xuLy9cbi8vIC0tLS0tLS0tLS1cbi8vXG4vLyBUaGVyZSBhcmUgdHdvIGRlZGljYXRlZCBiYWNrZ3JvdW5kIGhhbmRsZXJzIHRoYXQsIHdoZW4gcHJvdmlkZWQgaW4gYGhhbmRsZXJzYFxuLy8gb2JqZWN0IGZvciBgYmdgIGNvbnRleHQgaW4gYGluaXRgIGZ1bmN0aW9uLCBhcmUgaW52b2tlZCBieSB0aGUgbWVzc2FnaW5nXG4vLyBzeXN0ZW0gaXRzZWxmLiBUaGVzZSBoYW5kbGVycyBhcmU6XG4vL1xuLy8gKyBvbkNvbm5lY3Q6IGZ1bmN0aW9uKGNvbnRleHROYW1lLCB0YWJJZCksXG4vLyArIG9uRGlzY29ubmVjdDogZnVuY3Rpb24oY29udGV4dE5hbWUsIHRhYklkKVxuLy9cbi8vIFRoZXNlIHR3byBzcGVjaWFsIGhhbmRsZXJzLCBpZiBwcm92aWRlZCwgYXJlIGludm9rZWQgd2hlbiBuZXcgUG9ydCBpc1xuLy8gY29ubmVjdGVkIChpLmUuIHdoZW4gYGluaXRgIGZ1bmN0aW9uIGlzIGludm9rZWQgaW4gbm9uLWJnIGNvbnRleHQpLCBhbmRcbi8vIHRoZW4gd2hlbiB0aGV5IGFyZSBjbG9zZWQgKGRpc2Nvbm5lY3RlZCkgbGF0ZXIgb24uIFRoaXMgbm90aWZpY2F0aW9uIHN5c3RlbVxuLy8gYWxsb3dzIHRvIG1haW50YWluIHNvbWUgc3RhdGUgYWJvdXQgY29ubmVjdGVkIGNvbnRleHRzIGluIGV4dGVuc2lvblxuLy8gYmFja3JvdW5kLlxuLy9cbi8vIFBsZWFzZSBub3RlIHRoYXQgdW5saWtlIGFsbCBvdGhlciBoYW5kbGVycyBwYXNzZWQgYXMgdGhlIGBoYW5kbGVyc2Agb2JqZWN0IHRvXG4vLyBgaW5pdGAgZnVuY3Rpb24sIHRoZXNlIHR3byBzcGVjaWFsIGhhbmRsZXJzIGRvIE5PVCB0YWtlIGNhbGxiYWNrIGFzIHRoZWlyXG4vLyBsYXN0IGFyZ3VtZW50cy4gQW55IHJldHVybiB2YWx1ZSB0aGVzZSBoYW5kbGVycyBtYXkgcmV0dXJuIGlzIGlnbm9yZWQuXG4vL1xuLy8gVGhlIGBjb250ZXh0TmFtZWAgcGFyYW1ldGVyIGlzIHZhbHVlIHByb3ZpZGVkIHRvIG5vbi1iYWNrZ3JvdW5kIGBpbml0YFxuLy8gZnVuY3Rpb24sIHdoaWxlIHRoZSBgdGFiSWRgIGlzIHByb3ZpZGVkIGJ5IHRoZSBicm93c2VyLiBJZiB0YWJJZCBpcyBub3Rcbi8vIHByb3ZpZGVkIGJ5IHRoZSBicm93c2VyLCB0aGUgYHRhYklkYCB3aWxsIGJlIGBJbmZpbml0eWAuXG4vL1xuXG5cbi8vIGNvbnN0YW50IGZvciBcInNhbWUgdGFiIGFzIG1lXCJcbnZhciBTQU1FX1RBQiA9IC0xMDAwOyAgLy8gd2FzIC1JbmZpbml0eSwgYnV0IEpTT04uc3RyaW5naWZ5KCkgKyBKU09OLnBhcnNlKCkgZG9uJ3QgbGlrZSB0aGF0IHZhbHVlXG5cbi8vIHJ1bi10aW1lIEFQSTpcbi8vIHZhcmlhYmxlICsgZXhwb3J0ZWQgZnVuY3Rpb24gdG8gY2hhbmdlIGl0LCBzbyBpdCBjYW4gYmUgbW9ja2VkIGluIHVuaXQgdGVzdHNcbi8qIGdsb2JhbCBjaHJvbWUgKi9cbnZhciBydW50aW1lID0gKCdvYmplY3QnID09PSB0eXBlb2YoY2hyb21lKSkgJiYgY2hyb21lLnJ1bnRpbWU7XG4vLyB0aGUgc2FtZSBmb3IgZGV2dG9vbHMgQVBJOlxudmFyIGRldnRvb2xzID0gKCdvYmplY3QnID09PSB0eXBlb2YoY2hyb21lKSkgJiYgY2hyb21lLmRldnRvb2xzO1xuXG4vLyB1dGlsaXR5IGZ1bmN0aW9uIGZvciBsb29waW5nIHRocm91Z2ggb2JqZWN0J3Mgb3duIGtleXNcbi8vIGNhbGxiYWNrOiBmdW5jdGlvbihrZXksIHZhbHVlLCBvYmopIC4uLiBkb2Vzbid0IG5lZWQgdG8gdXNlIGFsbCAzIHBhcmFtZXRlcnNcbi8vIHJldHVybnMgb2JqZWN0IHdpdGggc2FtZSBrZXlzIGFzIHRoZSBjYWxsYmFjayB3YXMgaW52b2tlZCBvbiwgdmFsdWVzIGFyZSB0aGVcbi8vICAgY2FsbGJhY2sgcmV0dXJuZWQgdmFsdWVzIC4uLiBjYW4gYmUgb2YgY291cnNlIGlnbm9yZWQgYnkgdGhlIGNhbGxlciwgdG9vXG5mdW5jdGlvbiBmb3JPd25Qcm9wcyhvYmosIGNhbGxiYWNrKSB7XG4gIGlmICgnZnVuY3Rpb24nICE9PSB0eXBlb2YoY2FsbGJhY2spKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIHZhciByZXMgPSB7fTtcbiAgZm9yICh2YXIga2V5IGluIG9iaikge1xuICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgcmVzW2tleV0gPSBjYWxsYmFjayhrZXksIG9ialtrZXldLCBvYmopO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzO1xufVxuXG4vLyB3ZSB3cmFwIHRoZSB3aG9sZSBtb2R1bGUgZnVuY3Rpb25hbGl0eSBpbnRvIGlzb2xhdGVkIHNjb3BlLCBzbyB0aGF0IGxhdGVyIHdlXG4vLyBjYW4gaW5zdGFudGlhdGUgbXVsdGlwbGUgcGFyYWxsZWwgc2NvcGVzIGZvciB1bml0IHRlc3RpbmcuXG4vLyBUaGUgbW9kdWxlIHdpbGwgc3RpbGwgc2VlbSB0byBob2xkIHNpbmdsZXRvbiBvYmplY3QsIGJlY2F1c2Ugd2UnbGwgY3JlYXRlXG4vLyB0aGlzIHNpbmdsZXRvbiBhbmQgd2lsbCBleHBvcnQgaXRzIG1ldGhvZHMgYXMgKHdob2xlKSBtb2R1bGUgbWV0aG9kcy5cblxuZnVuY3Rpb24gTWVzc2FnaW5nKCkge1xuICAvLyBoYW5kbGVycyBhdmFpbGFibGUgaW4gZ2l2ZW4gY29udGV4dCAoZnVuY3Rpb24gbG9va3VwIHRhYmxlKSwgc2V0IGluIGBpbml0KClgXG4gIC8vIGZvcm1hdDpcbiAgLy8ge1xuICAvLyAgIChzdHJpbmcpPGZ1bmN0aW9OYW1lPjogKGZ1bmN0aW9uKTxjb2RlPixcbiAgLy8gICAuLi5cbiAgLy8gfVxuICB0aGlzLmhhbmRsZXJzID0ge307XG5cbiAgLy8gaWQgYXNzaWduZWQgYnkgYmFja2dyb3VuZCwgdXNlZCBpbiBub24tYmFja2dyb3VuZCBjb250ZXh0cyBvbmx5XG4gIC8vIGluIGJhY2tncm91bmQgc2V0IHRvICdiZydcbiAgdGhpcy5pZCA9IG51bGw7XG5cbiAgLy8gcG9ydCB1c2VkIGZvciBjb21tdW5pY2F0aW9uIHdpdGggYmFja2dyb3VuZCAoaS5lLiBub3QgdXNlZCBpbiBiYWNrZ3JvdW5kKVxuICAvLyB0eXBlOiAoY2hyb21lLnJ1bnRpbWUpIFBvcnRcbiAgdGhpcy5wb3J0ID0gbnVsbDtcblxuICAvLyBjYWxsYmFjayBsb29rdXAgdGFibGU6IGlmIHJlcXVlc3Qgd2FpdHMgZm9yIHJlc3BvbnNlLCB0aGlzIHRhYmxlIGhvbGRzXG4gIC8vIHRoZSBjYWxsYmFjayBmdW5jdGlvbiB0aGF0IHdpbGwgYmUgaW52b2tlIHVwb24gcmVzcG9uc2VcbiAgLy8gZm9ybWF0OlxuICAvLyB7XG4gIC8vICAgKGludCk8cmVxdWVzdElkPjogKGZ1bmN0aW9uKTxjYWxsYmFjayBjb2RlPixcbiAgLy8gICAuLi5cbiAgLy8gfVxuICB0aGlzLmNiVGFibGUgPSB7fTtcblxuICAvLyBiYWNrZ3JvdW5kIHRhYmxlIG9mIHBlbmRpbmcgcmVxdWVzdHNcbiAgLy8gZm9ybWF0OlxuICAvLyB7XG4gIC8vICAgKHN0cmluZyk8cG9ydElkPjogWyB7IGlkOiAoaW50KTxyZXF1ZXN0SWQ+LCBjYjogKGZ1bmN0aW9uKTxjYWxsYmFjaz4gfSwgLi4uXSxcbiAgLy8gICAuLi5cbiAgLy8gfVxuICB0aGlzLnBlbmRpbmdSZXFzID0ge307XG5cbiAgLy8gdW5pcXVlIGNvbnRleHQgaWQsIHVzZWQgYnkgYmFja2dyb3VuZFxuICB0aGlzLnVJZCA9IDE7XG5cbiAgLy8gcmVxdWVzdCBpZCwgdXNlZCBieSBhbGwgY29udGV4dHNcbiAgdGhpcy5yZXF1ZXN0SWQgPSAxO1xuXG4gIC8vIG1hcHBpbmcgbm9uLWJhY2tncm91bmQgY29udGV4dCBuYW1lcyB0byBvYmplY3RzIGluZGV4ZWQgYnkgbmFtZSBvZiB0aGUgY29udGV4dFxuICAvLyBpbnN0YW5jZXMsIGhvbGRpbmcgeyB0YWItaWQsIChjaHJvbWUucnVudGltZS4pUG9ydCB9IHBhaXJzLFxuICAvLyB1c2VkIGZvciBtZXNzYWdlIGRpc3BhdGNoaW5nXG4gIC8vIGZvcm1hdDpcbiAgLy8ge1xuICAvLyAgIChzdHJpbmcpPGNhdGVnb3J5Pjoge1xuICAvLyAgICAgKHN0cmluZyk8aWQ+OiB7IHRhYklkOiAob3B0aW9uYWwpPGludD4sIHBvcnQ6IDxjaHJvbWUucnVudGltZS5Qb3J0PiB9LFxuICAvLyAgICAgLi4uXG4gIC8vICAgfSxcbiAgLy8gICAuLi5cbiAgLy8gfVxuICAvLyBiYWNrZ3JvdW5kLW9ubHkgdmFyaWFibGVcbiAgdGhpcy5wb3J0TWFwID0ge307XG5cbiAgLy8gcnVuZXRpbWUgYW5kIGRldnRvb2xzIHJlZmVyZW5jZXMsIHNvIHRoYXQgd2UgY2FuIGNoYW5nZSBpdCBpbiB1bml0IHRlc3RzXG4gIHRoaXMucnVudGltZSA9IHJ1bnRpbWU7XG4gIHRoaXMuZGV2dG9vbHMgPSBkZXZ0b29scztcbn1cblxuLy8gYmFja2dyb3VuZCBmdW5jdGlvbiBmb3Igc2VsZWN0aW5nIHRhcmdldCBwb3J0cyB0byB3aGljaCB3ZSBicm9hZGNhc3QgdGhlIHJlcXVlc3Rcbi8vIGZyb21CZzogaXMgdGhlIHJlcXVlc3QgdG8gY29sbGVjdCB0YXJnZXRzIGZyb20gYmFjZ3JvdW5kLCBvciBiYXNlZCBvbiBtZXNzYWdlP1xuLy8gdGFyZyo6IGZpbHRlciBmb3IgdGFyZ2V0IHBvcnRzXG4vLyBzcmMqOiBpbmZvcm1hdGlvbiBhYm91dCBzb3VyY2UgcG9ydFxuLy8gcmV0dXJucyBhcnJheSBvZiB7IHBvcnQ6IChjaHJvbWUucnVudGltZS5Qb3J0KSwgaWQ6IChzdHJpbmcpIH1cbk1lc3NhZ2luZy5wcm90b3R5cGUuc2VsZWN0VGFyZ2V0cyA9IGZ1bmN0aW9uKGZyb21CZywgdGFyZ1RhYklkLCB0YXJnQ2F0ZWdvcmllcywgc3JjQ2F0ZWdvcnksIHNyY1BvcnRJZCkge1xuICB2YXIgcmVzID0gW107XG4gIHZhciBfcG9ydCA9IHRoaXMucG9ydE1hcFtzcmNDYXRlZ29yeV0gJiYgdGhpcy5wb3J0TWFwW3NyY0NhdGVnb3J5XVtzcmNQb3J0SWRdO1xuICBpZiAoIWZyb21CZyAmJiAhX3BvcnQpIHtcbiAgICAvLyB0aGlzIHNob3VsZCBuZXZlciBoYXBwZW4sIHdlIGp1c3QgZ290IHJlcXVlc3QgZnJvbSB0aGlzIHBvcnQhXG4gICAgcmV0dXJuIFtdO1xuICB9XG4gIGlmICghZnJvbUJnICYmICh0YXJnVGFiSWQgPT09IFNBTUVfVEFCKSkge1xuICAgIHRhcmdUYWJJZCA9IF9wb3J0LnRhYklkO1xuICB9XG4gIC8vIGl0ZXJhdGUgdGhyb3VnaCBwb3J0TWFwLCBwaWNrIHRhcmdldHM6XG4gIGZvck93blByb3BzKHRoaXMucG9ydE1hcCwgZnVuY3Rpb24oY2F0ZWcsIHBvcnRHcm91cCkge1xuICAgIGlmICh0YXJnQ2F0ZWdvcmllcyAmJiAoLTEgPT09IHRhcmdDYXRlZ29yaWVzLmluZGV4T2YoY2F0ZWcpKSkge1xuICAgICAgLy8gd2UgYXJlIGludGVyZXN0ZWQgb25seSBpbiBzcGVjaWZpZWQgY29udGV4dHMsXG4gICAgICAvLyBhbmQgdGhpcyBjYXRlZ29yeSBpcyBub3Qgb24gdGhlIGxpc3RcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZm9yT3duUHJvcHMocG9ydEdyb3VwLCBmdW5jdGlvbihpZCwgX3JlZikge1xuICAgICAgaWYgKHRhcmdUYWJJZCAmJiAodGFyZ1RhYklkICE9PSBfcmVmLnRhYklkKSkge1xuICAgICAgICAvLyB3ZSBhcmUgaW50ZXJlc3RlZCBpbiBzcGVjaWZpZWQgdGFiIGlkLFxuICAgICAgICAvLyBhbmQgdGhpcyBpZCBkb2Vzbid0IG1hdGNoXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChmcm9tQmcgfHwgKF9wb3J0LnBvcnQgIT09IF9yZWYucG9ydCkpIHtcbiAgICAgICAgLy8gZG8gbm90IGFzayBtZSBiYWNrLCBhc2sgb25seSBkaWZmZXJlbnQgcG9ydHNcbiAgICAgICAgcmVzLnB1c2goeyBwb3J0OiBfcmVmLnBvcnQsIGlkOiBpZCB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG4gIHJldHVybiByZXM7XG59O1xuXG4vLyBtZXNzYWdlIGhhbmRsZXIgKHVzZWIgYnkgYm90aCBiYWNrZ3JvdW5kIGFuZCBub24tYmFja291bmQpXG5NZXNzYWdpbmcucHJvdG90eXBlLm9uQ3VzdG9tTXNnID0gZnVuY3Rpb24obWVzc2FnZSkge1xuXG4gIHZhciBfcG9ydCwgX2FyciwgX2xvY2FsSGFuZGxlciwgX3JlZiwgaTtcblxuICAvLyBoZWxwZXIgZnVuY3Rpb25zOlxuXG4gIC8vIHNlbmQgcmVzcG9uc2Ugb24gcmVzdWx0IChub24tYmFja2dyb3VuZCk6XG4gIGZ1bmN0aW9uIHNlbmRSZXN1bHRDYihyZXN1bHQpIHtcbiAgICBpZiAobWVzc2FnZS5zZW5kUmVzcG9uc2UpIHtcbiAgICAgIHRoaXMucG9ydC5wb3N0TWVzc2FnZSh7XG4gICAgICAgIGNtZDogJ3Jlc3BvbnNlJyxcbiAgICAgICAgcG9ydElkOiB0aGlzLmlkLFxuICAgICAgICByZXFJZDogbWVzc2FnZS5yZXFJZCxcbiAgICAgICAgcmVzdWx0VmFsaWQ6IHRydWUsXG4gICAgICAgIHJlc3VsdDogcmVzdWx0XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICAvLyBjcmVhdGUgY2FsbGJhY2sgd2FpdGluZyBmb3IgTiByZXN1bHRzLCB0aGVuIHNlbmQgcmVzcG9uc2UgKGJhY2tncm91bmQpOlxuICBmdW5jdGlvbiBjcmVhdGVDYkZvck1vcmVSZXN1bHRzKE4pIHtcbiAgICB2YXIgcmVzdWx0cyA9IFtdO1xuICAgIHJldHVybiBmdW5jdGlvbihyZXN1bHQsIHJlc3VsdFZhbGlkKSB7XG4gICAgICBpZiAocmVzdWx0VmFsaWQgIT09IGZhbHNlKSB7ICAvLyBjYW4gYmUgZWl0aGVyIGB0cnVlYCBvciBgdW5kZWZpbmVkYFxuICAgICAgICByZXN1bHRzLnB1c2gocmVzdWx0KTtcbiAgICAgIH1cbiAgICAgIE4tLTtcbiAgICAgIGlmICghTiAmJiBtZXNzYWdlLnNlbmRSZXNwb25zZSAmJiB0aGlzLnBvcnRNYXBbbWVzc2FnZS5jYXRlZ29yeV0gJiZcbiAgICAgICAgICAoX3BvcnQgPSB0aGlzLnBvcnRNYXBbbWVzc2FnZS5jYXRlZ29yeV1bbWVzc2FnZS5wb3J0SWRdKSkge1xuICAgICAgICBfcG9ydC5wb3J0LnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICBjbWQ6ICdyZXNwb25zZScsXG4gICAgICAgICAgcmVxSWQ6IG1lc3NhZ2UucmVxSWQsXG4gICAgICAgICAgcmVzdWx0OiBtZXNzYWdlLmJyb2FkY2FzdCA/IHJlc3VsdHMgOiByZXN1bHRzWzBdXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0uYmluZCh0aGlzKTtcbiAgfVxuXG4gIC8vIG1haW4gbWVzc2FnZSBwcm9jZXNzaW5nOlxuICBpZiAoIW1lc3NhZ2UgfHwgIW1lc3NhZ2UuY21kKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICgnc2V0TmFtZScgPT09IG1lc3NhZ2UuY21kKSB7XG4gICAgdGhpcy5pZCA9IG1lc3NhZ2UubmFtZTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKCdiZycgPT09IHRoaXMuaWQpIHtcbiAgICAvLyBiYWNrZ3JvdW5kXG4gICAgaWYgKCdyZXF1ZXN0JyA9PT0gbWVzc2FnZS5jbWQpIHtcbiAgICAgIHZhciB0YXJnZXRQb3J0cyA9IHRoaXMuc2VsZWN0VGFyZ2V0cyhmYWxzZSwgbWVzc2FnZS50YWJJZCwgbWVzc2FnZS5jb250ZXh0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlLmNhdGVnb3J5LCBtZXNzYWdlLnBvcnRJZCk7XG4gICAgICB2YXIgcmVzcG9uc2VzTmVlZGVkID0gdGFyZ2V0UG9ydHMubGVuZ3RoO1xuICAgICAgaWYgKCAodW5kZWZpbmVkID09PSBtZXNzYWdlLnRhYklkKSAmJlxuICAgICAgICAgICAoIW1lc3NhZ2UuY29udGV4dHMgfHwgKC0xICE9PSBtZXNzYWdlLmNvbnRleHRzLmluZGV4T2YoJ2JnJykpKSApIHtcbiAgICAgICAgLy8gd2UgYXJlIGFsc28gaW50ZXJlc3RlZCBpbiByZXNwb25zZSBmcm9tIGJhY2tncm91bmQgaXRzZWxmXG4gICAgICAgIGlmICgoX3JlZiA9IHRoaXMuaGFuZGxlcnNbbWVzc2FnZS5jbWROYW1lXSkgJiYgKCdmdW5jdGlvbicgPT09IHR5cGVvZihfcmVmKSkpIHtcbiAgICAgICAgICBfbG9jYWxIYW5kbGVyID0gX3JlZjtcbiAgICAgICAgICByZXNwb25zZXNOZWVkZWQrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFyZXNwb25zZXNOZWVkZWQpIHtcbiAgICAgICAgLy8gbm8gb25lIHRvIGFuc3dlciB0aGF0IG5vd1xuICAgICAgICBpZiAobWVzc2FnZS5zZW5kUmVzcG9uc2UgJiYgdGhpcy5wb3J0TWFwW21lc3NhZ2UuY2F0ZWdvcnldICYmXG4gICAgICAgICAgICAoX3BvcnQgPSB0aGlzLnBvcnRNYXBbbWVzc2FnZS5jYXRlZ29yeV1bbWVzc2FnZS5wb3J0SWRdKSkge1xuICAgICAgICAgIF9wb3J0LnBvcnQucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgY21kOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgcmVxSWQ6IG1lc3NhZ2UucmVxSWQsXG4gICAgICAgICAgICByZXN1bHRWYWxpZDogZmFsc2UsXG4gICAgICAgICAgICByZXN1bHQ6IG1lc3NhZ2UuYnJvYWRjYXN0ID8gW10gOiB1bmRlZmluZWRcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gc29tZSByZXNwb25zZXMgbmVlZGVkXG4gICAgICAgIHZhciBjYiA9IGNyZWF0ZUNiRm9yTW9yZVJlc3VsdHMuY2FsbCh0aGlzLCByZXNwb25zZXNOZWVkZWQpO1xuICAgICAgICAvLyBzZW5kIHRvIHRhcmdldCBwb3J0c1xuICAgICAgICBmb3IgKGkgPSAwOyBpIDwgdGFyZ2V0UG9ydHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBfcG9ydCA9IHRhcmdldFBvcnRzW2ldO1xuICAgICAgICAgIF9wb3J0LnBvcnQucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgY21kOiAncmVxdWVzdCcsXG4gICAgICAgICAgICBjbWROYW1lOiBtZXNzYWdlLmNtZE5hbWUsXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2U6IHRydWUsXG4gICAgICAgICAgICBhcmdzOiBtZXNzYWdlLmFyZ3MsXG4gICAgICAgICAgICByZXFJZDogdGhpcy5yZXF1ZXN0SWRcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBfYXJyID0gdGhpcy5wZW5kaW5nUmVxc1tfcG9ydC5pZF0gfHwgW107XG4gICAgICAgICAgX2Fyci5wdXNoKHsgaWQ6IHRoaXMucmVxdWVzdElkLCBjYjogY2IgfSk7XG4gICAgICAgICAgdGhpcy5wZW5kaW5nUmVxc1tfcG9ydC5pZF0gPSBfYXJyO1xuICAgICAgICAgIHRoaXMucmVxdWVzdElkKys7XG4gICAgICAgIH1cbiAgICAgICAgLy8gZ2V0IGxvY2FsIHJlc3BvbnNlIChpZiBiYWNrZ3JvdW5kIGNhbiBwcm92aWRlIGl0KVxuICAgICAgICBpZiAoX2xvY2FsSGFuZGxlcikge1xuICAgICAgICAgIG1lc3NhZ2UuYXJncy5wdXNoKGNiKTtcbiAgICAgICAgICBfbG9jYWxIYW5kbGVyLmFwcGx5KHRoaXMuaGFuZGxlcnMsIG1lc3NhZ2UuYXJncyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCdyZXNwb25zZScgPT09IG1lc3NhZ2UuY21kKSB7XG4gICAgICBfYXJyID0gdGhpcy5wZW5kaW5nUmVxc1ttZXNzYWdlLnBvcnRJZF07ICAvLyB3YXJuaW5nOiBJRSBjcmVhdGVzIGEgY29weSBoZXJlIVxuICAgICAgaWYgKF9hcnIpIHtcbiAgICAgICAgLy8gc29tZSByZXN1bHRzIGZyb20gZ2l2ZW4gcG9ydCBleHBlY3RlZCwgZmluZCB0aGUgY2FsbGJhY2sgZm9yIHJlcUlkXG4gICAgICAgIGkgPSAwO1xuICAgICAgICB3aGlsZSAoKGkgPCBfYXJyLmxlbmd0aCkgJiYgKF9hcnJbaV0uaWQgIT09IG1lc3NhZ2UucmVxSWQpKSB7IGkrKzsgfVxuICAgICAgICBpZiAoaSA8IF9hcnIubGVuZ3RoKSB7XG4gICAgICAgICAgLy8gY2FsbGJhY2sgZm91bmRcbiAgICAgICAgICBfYXJyW2ldLmNiKG1lc3NhZ2UucmVzdWx0LCBtZXNzYWdlLnJlc3VsdFZhbGlkKTtcbiAgICAgICAgICB0aGlzLnBlbmRpbmdSZXFzW21lc3NhZ2UucG9ydElkXS5zcGxpY2UoaSwgMSk7ICAgLy8gbmVlZCB0byB1c2Ugb3JpZyBhcnJheSAoSUUgcHJvYmxlbSlcbiAgICAgICAgICBpZiAoIXRoaXMucGVuZGluZ1JlcXNbbWVzc2FnZS5wb3J0SWRdLmxlbmd0aCkgeyAgLy8gLi4uIHNhbWUgaGVyZVxuICAgICAgICAgICAgZGVsZXRlIHRoaXMucGVuZGluZ1JlcXNbbWVzc2FnZS5wb3J0SWRdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoJ3VwZGF0ZVRhYklkJyA9PT0gbWVzc2FnZS5jbWQpIHtcbiAgICAgIHZhciBfY29udGV4dCA9IG1lc3NhZ2UuY29udGV4dCwgX3BvcnRJZCA9IG1lc3NhZ2UucG9ydElkO1xuICAgICAgaWYgKChfcG9ydCA9IHRoaXMucG9ydE1hcFtfY29udGV4dF0pICYmIChfcG9ydCA9IF9wb3J0W19wb3J0SWRdKSkge1xuICAgICAgICBpZiAoJ2Z1bmN0aW9uJyA9PT0gdHlwZW9mKHRoaXMuaGFuZGxlcnMub25EaXNjb25uZWN0KSkgeyB0aGlzLmhhbmRsZXJzLm9uRGlzY29ubmVjdChfY29udGV4dCwgX3BvcnQudGFiSWQpOyB9XG4gICAgICAgIF9wb3J0LnRhYklkID0gbWVzc2FnZS50YWJJZDtcbiAgICAgICAgaWYgKCdmdW5jdGlvbicgPT09IHR5cGVvZih0aGlzLmhhbmRsZXJzLm9uQ29ubmVjdCkpIHsgdGhpcy5oYW5kbGVycy5vbkNvbm5lY3QoX2NvbnRleHQsIF9wb3J0LnRhYklkKTsgfVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyBub24tYmFja2dyb3VuZFxuICAgIGlmICgncmVxdWVzdCcgPT09IG1lc3NhZ2UuY21kKSB7XG4gICAgICBfbG9jYWxIYW5kbGVyID0gdGhpcy5oYW5kbGVyc1ttZXNzYWdlLmNtZE5hbWVdO1xuICAgICAgaWYgKCdmdW5jdGlvbicgIT09IHR5cGVvZihfbG9jYWxIYW5kbGVyKSkge1xuICAgICAgICBpZiAobWVzc2FnZS5zZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgICB0aGlzLnBvcnQucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgY21kOiAncmVzcG9uc2UnLFxuICAgICAgICAgICAgcG9ydElkOiB0aGlzLmlkLFxuICAgICAgICAgICAgcmVxSWQ6IG1lc3NhZ2UucmVxSWQsXG4gICAgICAgICAgICByZXN1bHRWYWxpZDogZmFsc2VcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWVzc2FnZS5hcmdzLnB1c2goc2VuZFJlc3VsdENiLmJpbmQodGhpcykpO1xuICAgICAgICBfbG9jYWxIYW5kbGVyLmFwcGx5KHRoaXMuaGFuZGxlcnMsIG1lc3NhZ2UuYXJncyk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICgncmVzcG9uc2UnID09PSBtZXNzYWdlLmNtZCkge1xuICAgICAgaWYgKHRoaXMuY2JUYWJsZVttZXNzYWdlLnJlcUlkXSkge1xuICAgICAgICB0aGlzLmNiVGFibGVbbWVzc2FnZS5yZXFJZF0obWVzc2FnZS5yZXN1bHQpO1xuICAgICAgICBkZWxldGUgdGhpcy5jYlRhYmxlW21lc3NhZ2UucmVxSWRdO1xuICAgICAgfVxuICAgIH1cbiAgfVxufTtcblxuLy8gaW52b2tlIGNhbGxiYWNrcyBmb3IgcGVuZGluZyByZXF1ZXN0cyBhbmQgcmVtb3ZlIHRoZSByZXF1ZXN0cyBmcm9tIHRoZSBzdHJ1Y3R1cmVcbk1lc3NhZ2luZy5wcm90b3R5cGUuY2xvc2VQZW5kaW5nUmVxcyA9IGZ1bmN0aW9uKHBvcnRJZCkge1xuICB2YXIgX2FycjtcbiAgaWYgKF9hcnIgPSB0aGlzLnBlbmRpbmdSZXFzW3BvcnRJZF0pIHtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IF9hcnIubGVuZ3RoOyBpKyspIHtcbiAgICAgIF9hcnJbaV0uY2IodW5kZWZpbmVkLCBmYWxzZSk7XG4gICAgfVxuICAgIGRlbGV0ZSB0aGlzLnBlbmRpbmdSZXFzW3BvcnRJZF07XG4gIH1cbn07XG5cbi8vIGJhY2tyb3VuZCBvbkNvbm5lY3QgaGFuZGxlclxuTWVzc2FnaW5nLnByb3RvdHlwZS5vbkNvbm5lY3QgPSBmdW5jdGlvbihwb3J0KSB7XG4gIC8vIGFkZCB0byBwb3J0IG1hcFxuICB2YXIgY2F0ZWdOYW1lID0gcG9ydC5uYW1lIHx8ICd1bmtub3duJztcbiAgdmFyIHBvcnRJZCA9IGNhdGVnTmFtZSArICctJyArIHRoaXMudUlkO1xuICB0aGlzLnVJZCsrO1xuICB2YXIgcG9ydENhdGVnID0gdGhpcy5wb3J0TWFwW2NhdGVnTmFtZV0gfHwge307XG4gIHZhciB0YWJJZCA9IChwb3J0LnNlbmRlciAmJiBwb3J0LnNlbmRlci50YWIgJiYgcG9ydC5zZW5kZXIudGFiLmlkKSB8fCBJbmZpbml0eTtcbiAgcG9ydENhdGVnW3BvcnRJZF0gPSB7XG4gICAgcG9ydDogcG9ydCxcbiAgICB0YWJJZDogdGFiSWRcbiAgfTtcbiAgdGhpcy5wb3J0TWFwW2NhdGVnTmFtZV0gPSBwb3J0Q2F0ZWc7XG4gIHZhciBfb25DdXN0b21Nc2csX29uRGlzY29ubmVjdDtcbiAgLy8gb24gZGlzY29ubmVjdDogcmVtb3ZlIGxpc3RlbmVycyBhbmQgZGVsZXRlIGZyb20gcG9ydCBtYXBcbiAgZnVuY3Rpb24gb25EaXNjb25uZWN0KCkge1xuICAgIC8vIGxpc3RlbmVyczpcbiAgICBwb3J0Lm9uRGlzY29ubmVjdC5yZW1vdmVMaXN0ZW5lcihfb25EaXNjb25uZWN0KTtcbiAgICBwb3J0Lm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcihfb25DdXN0b21Nc2cpO1xuICAgIC8vIHBvcnQgbWFwOlxuICAgIHBvcnRDYXRlZyA9IHRoaXMucG9ydE1hcFtjYXRlZ05hbWVdO1xuICAgIHZhciBfcG9ydDtcbiAgICBpZiAocG9ydENhdGVnICYmIChfcG9ydCA9IHBvcnRDYXRlZ1twb3J0SWRdKSkge1xuICAgICAgdGFiSWQgPSBfcG9ydC50YWJJZDtcbiAgICAgIGRlbGV0ZSBwb3J0Q2F0ZWdbcG9ydElkXTtcbiAgICB9XG4gICAgLy8gY2xvc2UgYWxsIHBlbmRpbmcgcmVxdWVzdHM6XG4gICAgdGhpcy5jbG9zZVBlbmRpbmdSZXFzKHBvcnRJZCk7XG4gICAgLy8gaW52b2tlIGN1c3RvbSBvbkRpc2Nvbm5lY3QgaGFuZGxlclxuICAgIGlmICgnZnVuY3Rpb24nID09PSB0eXBlb2YodGhpcy5oYW5kbGVycy5vbkRpc2Nvbm5lY3QpKSB7IHRoaXMuaGFuZGxlcnMub25EaXNjb25uZWN0KGNhdGVnTmFtZSwgdGFiSWQpOyB9XG4gIH1cbiAgLy8gaW5zdGFsbCBwb3J0IGhhbmRsZXJzXG4gIHBvcnQub25NZXNzYWdlLmFkZExpc3RlbmVyKF9vbkN1c3RvbU1zZyA9IHRoaXMub25DdXN0b21Nc2cuYmluZCh0aGlzKSk7XG4gIHBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKF9vbkRpc2Nvbm5lY3QgPSBvbkRpc2Nvbm5lY3QuYmluZCh0aGlzKSk7XG4gIC8vIGFzayBjb3VudGVyIHBhcnQgdG8gc2V0IGl0cyBpZFxuICBwb3J0LnBvc3RNZXNzYWdlKHsgY21kOiAnc2V0TmFtZScsIG5hbWU6IHBvcnRJZCB9KTtcbiAgLy8gaW52b2tlIGN1c3RvbSBvbkNvbm5lY3QgaGFuZGxlclxuICBpZiAoJ2Z1bmN0aW9uJyA9PT0gdHlwZW9mKHRoaXMuaGFuZGxlcnMub25Db25uZWN0KSkgeyB0aGlzLmhhbmRsZXJzLm9uQ29ubmVjdChjYXRlZ05hbWUsIHRhYklkKTsgfVxufTtcblxuLy8gY3JlYXRlIG1haW4gbWVzc2FnaW5nIG9iamVjdCwgaGlkaW5nIGFsbCB0aGUgY29tcGxleGl0eSBmcm9tIHRoZSB1c2VyXG4vLyBpdCB0YWtlcyBuYW1lIG9mIGxvY2FsIGNvbnRleHQgYG15Q29udGV4dE5hbWVgXG4vL1xuLy8gdGhlIHJldHVybmVkIG9iamVjdCBoYXMgdHdvIG1haW4gZnVuY3Rpb25zOiBjbWQgYW5kIGJjYXN0XG4vL1xuLy8gdGhleSBiZWhhdmUgdGhlIHNhbWUgd2F5IGFuZCBoYXZlIGFsc28gdGhlIHNhbWUgYXJndW1lbnRzLCB0aGUgb25seVxuLy8gZGlmZmVyZW5jZSBpcyB0aGF0IHRvIGBjbWRgIGNhbGxiYWNrIChpZiBwcm92aWRlZCkgaXMgaW52b2tlZCB3aXRoIG9ubHkgb25lXG4vLyByZXNwb25zZSB2YWx1ZSBmcm9tIGFsbCBwb3NzaWJsZSByZXNwb25zZXMsIHdoaWxlIHRvIGBiY2FzdGAgY2FsbGJhY2sgKGlmXG4vLyBwcm92aWRlZCkgd2UgcGFzcyBhcnJheSB3aXRoIGFsbCB2YWxpZCByZXNwb25zZXMgd2UgY29sbGVjdGVkIHdoaWxlXG4vLyBicm9hZGNhc3RpbmcgZ2l2ZW4gcmVxdWVzdC5cbi8vXG4vLyBmdW5jdGlvbnMgYXJndW1lbnRzOlxuLy9cbi8vIChvcHRpb25hbCkgW2ludF0gdGFiSWQ6IGlmIG5vdCBzcGVjaWZpZWQsIGJyb2FkY2FzdGVkIHRvIGFsbCB0YWJzLFxuLy8gICAgICBpZiBzcGVjaWZpZWQsIHNlbnQgb25seSB0byBnaXZlbiB0YWIsIGNhbiB1c2UgU0FNRV9UQUIgdmFsdWUgaGVyZVxuLy9cbi8vIChvcHRpb25hbCkgW2FycmF5XSBjb250ZXh0czogaWYgbm90IHNwZWNpZmllZCwgYnJvYWRjYXN0ZWQgdG8gYWxsIGNvbnRleHRzLFxuLy8gICAgICBpZiBzcGVjaWZpZWQsIHNlbnQgb25seSB0byBsaXN0ZWQgY29udGV4dHNcbi8vXG4vLyAocmVxdWlyZWQpIFtzdHJpbmddIGNvbW1hbmQ6IG5hbWUgb2YgdGhlIGNvbW1hbmQgdG8gYmUgZXhlY3V0ZWRcbi8vXG4vLyAob3B0aW9uYWwpIFthbnkgdHlwZV0gYXJndW1lbnRzOiBhbnkgbnVtYmVyIG9mIGFydW1lbnRzIHRoYXQgZm9sbG93IGNvbW1hbmRcbi8vICAgICAgbmFtZSBhcmUgcGFzc2VkIHRvIGV4ZWN1dGlvbiBoYW5kbGVyIHdoZW4gaXQgaXMgaW52b2tlZFxuLy9cbi8vIChvcHRpb25hbCkgW2Z1bmN0aW9uKHJlc3VsdCldIGNhbGxiYWNrOiBpZiBwcm92aWRlZCAoYXMgbGFzdCBhcmd1bWVudCB0b1xuLy8gICAgICBgY21kYCBvciBgYmNhc3RgKSB0aGlzIGZ1bmN0aW9uIHdpbGwgYmUgaW52b2tlZCB3aGVuIHRoZSByZXNwb25zZShzKVxuLy8gICAgICBpcy9hcmUgcmVjZWl2ZWRcbi8vXG4vLyB0aGUgZnVuY3Rpb25zIHJldHVybiBgdHJ1ZWAgaWYgdGhlIHByb2Nlc3Npbmcgb2YgdGhlIHJlcXVlc3Qgd2FzIHN1Y2Nlc3NmdWxcbi8vIChpLmUuIGlmIGFsbCB0aGUgYXJndW1lbnRzIHdlcmUgcmVjb2duaXplZCBwcm9wZXJseSksIG90aGVyd2lzZSBpdCByZXR1cm5zXG4vLyBgZmFsc2VgLlxuLy9cbi8vIGZvciBub24tYmcgY29udGV4dHMgdGhlcmUgaXMgb25lIG1vcmUgZnVuY3Rpb24gaW4gdGhlIG1lc3NhZ2luZyBvYmplY3Rcbi8vIGF2YWlsYWJsZTogJ2JnJyBmdW5jdGlvbiwgdGhhdCBpcyB0aGUgc2FtZSBhcyAnY21kJywgYnV0IHByZXBlbmRzIHRoZSBsaXN0IG9mXG4vLyBhcmd1bWVudHMgd2l0aCBbJ2JnJ10sIHNvIHRoYXQgdGhlIHVzZXIgZG9lc24ndCBoYXZlIHRvIHdyaXRlIGl0IHdoZW5cbi8vIHJlcXVlc3Rpbmcgc29tZSBpbmZvIGluIG5vbi1iZyBjb250ZXh0IGZyb20gYmFja2dyb3VuZC5cbi8vXG5NZXNzYWdpbmcucHJvdG90eXBlLmNyZWF0ZU1zZ09iamVjdCA9IGZ1bmN0aW9uKG15Q29udGV4dE5hbWUpIHtcbiAgLy8gZ2VuZXJhdG9yIGZvciBmdW5jdGlvbnMgYGNtZGAgYW5kIGBiY2FzdGBcbiAgZnVuY3Rpb24gY3JlYXRlRm4oYnJvYWRjYXN0KSB7XG4gICAgLy8gaGVscGVyIGZ1bmN0aW9uIGZvciBpbnZva2luZyBwcm92aWRlZCBjYWxsYmFjayBpbiBiYWNrZ3JvdW5kXG4gICAgZnVuY3Rpb24gY3JlYXRlQ2JGb3JNb3JlUmVzdWx0cyhOLCBjYWxsYmFjaykge1xuICAgICAgdmFyIHJlc3VsdHMgPSBbXTtcbiAgICAgIHJldHVybiBmdW5jdGlvbihyZXN1bHQsIHJlc3VsdFZhbGlkKSB7XG4gICAgICAgIGlmIChyZXN1bHRWYWxpZCkge1xuICAgICAgICAgIHJlc3VsdHMucHVzaChyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIE4tLTtcbiAgICAgICAgaWYgKChOIDw9IDApICYmIGNhbGxiYWNrKSB7XG4gICAgICAgICAgY2FsbGJhY2soYnJvYWRjYXN0ID8gcmVzdWx0cyA6IHJlc3VsdHNbMF0pO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH1cbiAgICAvLyBnZW5lcmF0ZWQgZnVuY3Rpb246XG4gICAgcmV0dXJuIGZ1bmN0aW9uIF9tc2coKSB7XG4gICAgICAvLyBwcm9jZXNzIGFyZ3VtZW50czpcbiAgICAgIGlmICghYXJndW1lbnRzLmxlbmd0aCkge1xuICAgICAgICAvLyBhdCBsZWFzdCBjb21tYW5kIG5hbWUgbXVzdCBiZSBwcm92aWRlZFxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuaWQpIHtcbiAgICAgICAgLy8gc2luY2Ugd2UgbGVhcm4gb3VyIGlkIG9mIG5vbi1iYWNrZ3JvdW5kIGNvbnRleHQgaW4gYXN5bmNocm9ub3VzXG4gICAgICAgIC8vIG1lc3NhZ2UsIHdlIG1heSBuZWVkIHRvIHdhaXQgZm9yIGl0Li4uXG4gICAgICAgIHZhciBfY3R4ID0gdGhpcywgX2FyZ3MgPSBhcmd1bWVudHM7XG4gICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7IF9tc2cuYXBwbHkoX2N0eCwgX2FyZ3MpOyB9LCAxKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICB2YXIgdGFiSWQsIGNvbnRleHRzLCBjbWROYW1lLCBhcmdzID0gW10sIGNhbGxiYWNrO1xuICAgICAgdmFyIGN1ckFyZyA9IDAsIGFyZ3NMaW1pdCA9IGFyZ3VtZW50cy5sZW5ndGg7XG4gICAgICAvLyBjaGVjayBpZiB3ZSBoYXZlIGNhbGxiYWNrOlxuICAgICAgaWYgKHR5cGVvZihhcmd1bWVudHNbYXJnc0xpbWl0LTFdKSA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBhcmdzTGltaXQtLTtcbiAgICAgICAgY2FsbGJhY2sgPSBhcmd1bWVudHNbYXJnc0xpbWl0XTtcbiAgICAgIH1cbiAgICAgIC8vIG90aGVyIGFyZ3VtZW50czpcbiAgICAgIHdoaWxlIChjdXJBcmcgPCBhcmdzTGltaXQpIHtcbiAgICAgICAgdmFyIGFyZyA9IGFyZ3VtZW50c1tjdXJBcmcrK107XG4gICAgICAgIGlmIChjbWROYW1lICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBhcmdzLnB1c2goYXJnKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICAvLyB3ZSBkb24ndCBoYXZlIGNvbW1hbmQgbmFtZSB5ZXQuLi5cbiAgICAgICAgc3dpdGNoICh0eXBlb2YoYXJnKSkge1xuICAgICAgICAgIC8vIHRhYiBpZFxuICAgICAgICAgIGNhc2UgJ251bWJlcic6XG4gICAgICAgICAgICBpZiAodGFiSWQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7IC8vIHdlIGFscmVhZHkgaGF2ZSB0YWIgaWQgLS0+IGludmFsaWQgYXJnc1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGFiSWQgPSBhcmc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAvLyBjb250ZXh0cyAgKGFycmF5KVxuICAgICAgICAgIGNhc2UgJ29iamVjdCc6XG4gICAgICAgICAgICBpZiAoKHR5cGVvZihhcmcubGVuZ3RoKSA9PT0gJ3VuZGVmaW5lZCcpIHx8IChjb250ZXh0cyAhPT0gdW5kZWZpbmVkKSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7IC8vIHdlIGVpdGhlciBoYXZlIGl0LCBvciBpdCBpcyBub3QgYXJyYXktbGlrZSBvYmplY3RcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRleHRzID0gYXJnO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgLy8gY29tbWFuZCBuYW1lXG4gICAgICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgICAgIGNtZE5hbWUgPSBhcmc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAvLyBhbnl0aGluZyBlbHNlIC0tPiBlcnJvclxuICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjbWROYW1lID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlOyAvLyBjb21tYW5kIG5hbWUgaXMgbWFuZGF0b3J5XG4gICAgICB9XG4gICAgICAvLyBzdG9yZSB0aGUgY2FsbGJhY2sgYW5kIGlzc3VlIHRoZSByZXF1ZXN0IChtZXNzYWdlKVxuICAgICAgaWYgKCdiZycgPT09IHRoaXMuaWQpIHtcbiAgICAgICAgdmFyIHRhcmdldFBvcnRzID0gdGhpcy5zZWxlY3RUYXJnZXRzKHRydWUsIHRhYklkLCBjb250ZXh0cyk7XG4gICAgICAgIHZhciByZXNwb25zZXNOZWVkZWQgPSB0YXJnZXRQb3J0cy5sZW5ndGg7XG4gICAgICAgIHZhciBjYiA9IGNyZWF0ZUNiRm9yTW9yZVJlc3VsdHMuY2FsbCh0aGlzLCByZXNwb25zZXNOZWVkZWQsIGNhbGxiYWNrKTtcbiAgICAgICAgLy8gc2VuZCB0byB0YXJnZXQgcG9ydHNcbiAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCB0YXJnZXRQb3J0cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIHZhciBfcG9ydCA9IHRhcmdldFBvcnRzW2ldO1xuICAgICAgICAgIF9wb3J0LnBvcnQucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgY21kOiAncmVxdWVzdCcsXG4gICAgICAgICAgICBjbWROYW1lOiBjbWROYW1lLFxuICAgICAgICAgICAgc2VuZFJlc3BvbnNlOiB0cnVlLFxuICAgICAgICAgICAgYXJnczogYXJncyxcbiAgICAgICAgICAgIHJlcUlkOiB0aGlzLnJlcXVlc3RJZFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIHZhciBfYXJyID0gdGhpcy5wZW5kaW5nUmVxc1tfcG9ydC5pZF0gfHwgW107XG4gICAgICAgICAgX2Fyci5wdXNoKHsgaWQ6IHRoaXMucmVxdWVzdElkLCBjYjogY2IgfSk7XG4gICAgICAgICAgdGhpcy5wZW5kaW5nUmVxc1tfcG9ydC5pZF0gPSBfYXJyO1xuICAgICAgICAgIHRoaXMucmVxdWVzdElkKys7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCF0YXJnZXRQb3J0cy5sZW5ndGgpIHtcbiAgICAgICAgICAvLyBubyBvbmUgdG8gcmVzcG9uZCwgaW52b2tlIHRoZSBjYWxsYmFjayAoaWYgcHJvdmlkZWQpIHJpZ2h0IGF3YXlcbiAgICAgICAgICBjYihudWxsLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgIHRoaXMuY2JUYWJsZVt0aGlzLnJlcXVlc3RJZF0gPSBjYWxsYmFjaztcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnBvcnQucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgIGNtZDogJ3JlcXVlc3QnLFxuICAgICAgICAgIGNtZE5hbWU6IGNtZE5hbWUsXG4gICAgICAgICAgcmVxSWQ6IHRoaXMucmVxdWVzdElkLFxuICAgICAgICAgIHNlbmRSZXNwb25zZTogKGNhbGxiYWNrICE9PSB1bmRlZmluZWQpLFxuICAgICAgICAgIGJyb2FkY2FzdDogYnJvYWRjYXN0LFxuICAgICAgICAgIGNhdGVnb3J5OiBteUNvbnRleHROYW1lLFxuICAgICAgICAgIHBvcnRJZDogdGhpcy5pZCxcbiAgICAgICAgICB0YWJJZDogdGFiSWQsXG4gICAgICAgICAgY29udGV4dHM6IGNvbnRleHRzLFxuICAgICAgICAgIGFyZ3M6IGFyZ3NcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMucmVxdWVzdElkKys7XG4gICAgICB9XG4gICAgICAvLyBldmVyeXRoaW5nIHdlbnQgT0tcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0uYmluZCh0aGlzKTtcbiAgfVxuXG4gIC8vIHJldHVybmVkIG9iamVjdDpcbiAgdmFyIHJlcyA9IHtcbiAgICBjbWQ6IGNyZWF0ZUZuLmNhbGwodGhpcywgZmFsc2UpLFxuICAgIGJjYXN0OiBjcmVhdGVGbi5jYWxsKHRoaXMsIHRydWUpXG4gIH07XG5cbiAgLy8gZm9yIG1vcmUgY29udmVuaWVuY2UgKHdoZW4gc2VuZGluZyByZXF1ZXN0IGZyb20gbm9uLWJnIHRvIGJhY2tncm91bmQgb25seSlcbiAgLy8gYWRkaW5nICdiZyg8Y21kTmFtZT4sIC4uLiknIGZ1bmN0aW9uLCB0aGF0IGlzIGVxdWl2YWxlbnQgdG8gXCJjbWQoWydiZyddLCA8Y21kTmFtZT4sIC4uLilcIlxuICBpZiAobXlDb250ZXh0TmFtZSAhPT0gJ2JnJykge1xuICAgIHJlcy5iZyA9IGZ1bmN0aW9uKCkge1xuICAgICAgaWYgKDAgPT09IGFyZ3VtZW50cy5sZW5ndGggfHwgJ3N0cmluZycgIT09IHR5cGVvZihhcmd1bWVudHNbMF0pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHZhciBhcmdzID0gW1snYmcnXV07XG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykgeyBhcmdzLnB1c2goYXJndW1lbnRzW2ldKTsgfVxuICAgICAgcmV0dXJuIHJlcy5jbWQuYXBwbHkocmVzLCBhcmdzKTtcbiAgICB9O1xuICB9XG5cbiAgcmV0dXJuIHJlcztcbn07XG5cbi8vIGluaXQgZnVuY3Rpb24sIGV4cG9ydGVkXG4vL1xuLy8gdGFrZXMgbWFuZGF0b3J5IGBjb250ZXh0YCwgaXQgaXMgYW55IHN0cmluZyAoZS5nLiAnY3QnLCAncG9wdXAnLCAuLi4pLFxuLy8gb25seSBvbmUgdmFsdWUgaXMgb2Ygc3BlY2lhbCBtZWFuaW5nOiAnYmcnIC4uLiBtdXN0IGJlIHVzZWQgZm9yIGluaXRpYWxpemluZ1xuLy8gb2YgdGhlIGJhY2tncm91bmQgcGFydCwgYW55IG90aGVyIGNvbnRleHQgaXMgY29uc2lkZXJlZCBub24tYmFja2dyb3VuZFxuLy9cbi8vIG9wdGlvbmFsbHkgdGFrZXMgYGhhbmRsZXJzYCwgd2hpY2ggaXMgb2JqZWN0IG1hcHBpbmcgZnVuY3Rpb24gbmFtZXMgdG9cbi8vIGZ1bmN0aW9uIGNvZGVzLCB0aGF0IGlzIHVzZWQgYXMgZnVuY3Rpb24gbG9va3VwIHRhYmxlLiBlYWNoIG1lc3NhZ2UgaGFuZGxpbmdcbi8vIGZ1bmN0aW9uIE1VU1QgdGFrZSBjYWxsYmFjayBhcyBpdHMgbGFzdCBhcmd1bWVudCBhbmQgaW52b2tlIHRoaXMgY2FsbGJhY2tcbi8vIHdoZW4gdGhlIG1lc3NhZ2UgaGFuZGxlciBpcyBkb25lIHdpdGggcHJvY2Vzc2luZyBvZiB0aGUgbWVzc2FnZSAocmVnYXJkbGVzc1xuLy8gaWYgc3luY2hyb25vdXMgb3IgYXN5bmNocm9ub3VzKS4gdGhlIGNhbGxiYWNrIHRha2VzIG9uZSBhcmd1bWVudCwgdGhpc1xuLy8gYXJndW1lbnQgaXMgdHJlYXRlZCBhcyByZXR1cm4gdmFsdWUgb2YgdGhlIG1lc3NhZ2UgaGFuZGxlci5cbi8vXG4vLyBmb3IgYmFja2dyb3VuZCAoYGNvbnRleHRgIGlzICdiZycpOiBpbnN0YWxscyBvbkNvbm5lY3QgbGlzdGVuZXJcbi8vIGZvciBub24tYmFja2dyb3VuZCBjb250ZXh0IGl0IGNvbm5lY3RzIHRvIGJhY2tncm91bmRcbi8vXG5NZXNzYWdpbmcucHJvdG90eXBlLmluaXQgPSBmdW5jdGlvbihjb250ZXh0LCBoYW5kbGVycykge1xuICAvLyBzZXQgbWVzc2FnZSBoYW5kbGVycyAob3B0aW9uYWwpXG4gIHRoaXMuaGFuZGxlcnMgPSBoYW5kbGVycyB8fCB7fTtcblxuICAvLyBsaXN0ZW5lciByZWZlcmVuY2VzXG4gIHZhciBfb25EaXNjb25uZWN0LCBfb25DdXN0b21Nc2c7XG5cbiAgLy8gaGVscGVyIGZ1bmN0aW9uOlxuICBmdW5jdGlvbiBvbkRpc2Nvbm5lY3QoKSB7XG4gICAgdGhpcy5wb3J0Lm9uRGlzY29ubmVjdC5yZW1vdmVMaXN0ZW5lcihfb25EaXNjb25uZWN0KTtcbiAgICB0aGlzLnBvcnQub25NZXNzYWdlLnJlbW92ZUxpc3RlbmVyKF9vbkN1c3RvbU1zZyk7XG4gIH1cblxuICB2YXIgX3RhYklkO1xuICBmdW5jdGlvbiBfdXBkYXRlVGFiSWQoKSB7XG4gICAgaWYgKCF0aGlzLmlkKSB7XG4gICAgICBzZXRUaW1lb3V0KF91cGRhdGVUYWJJZC5iaW5kKHRoaXMpLCAxKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5wb3J0LnBvc3RNZXNzYWdlKHtcbiAgICAgIGNtZDogJ3VwZGF0ZVRhYklkJyxcbiAgICAgIGNvbnRleHQ6IGNvbnRleHQsXG4gICAgICBwb3J0SWQ6IHRoaXMuaWQsXG4gICAgICB0YWJJZDogX3RhYklkXG4gICAgfSk7XG4gIH1cblxuICBpZiAoJ2JnJyA9PT0gY29udGV4dCkge1xuICAgIC8vIGJhY2tncm91bmRcbiAgICB0aGlzLmlkID0gJ2JnJztcbiAgICB0aGlzLnJ1bnRpbWUub25Db25uZWN0LmFkZExpc3RlbmVyKHRoaXMub25Db25uZWN0LmJpbmQodGhpcykpO1xuICB9IGVsc2Uge1xuICAgIC8vIGFueXRoaW5nIGVsc2UgdGhhbiBiYWNrZ3JvdW5kXG4gICAgdGhpcy5wb3J0ID0gdGhpcy5ydW50aW1lLmNvbm5lY3QoeyBuYW1lOiBjb250ZXh0IH0pO1xuICAgIHRoaXMucG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoX29uQ3VzdG9tTXNnID0gdGhpcy5vbkN1c3RvbU1zZy5iaW5kKHRoaXMpKTtcbiAgICB0aGlzLnBvcnQub25EaXNjb25uZWN0LmFkZExpc3RlbmVyKF9vbkRpc2Nvbm5lY3QgPSBvbkRpc2Nvbm5lY3QuYmluZCh0aGlzKSk7XG4gICAgLy8gdGFiSWQgdXBkYXRlIGZvciBkZXZlbG9wZXIgdG9vbHNcbiAgICAvLyB1bmZvcnR1bmF0ZWx5IHdlIG5lZWQgZGVkaWNhdGVkIG5hbWUgZm9yIGRldmVsb3BlciB0b29scyBjb250ZXh0LCBkdWUgdG9cbiAgICAvLyB0aGlzIGJ1ZzogaHR0cHM6Ly9jb2RlLmdvb2dsZS5jb20vcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTM1NjEzM1xuICAgIC8vIC4uLiB3ZSBhcmUgbm90IGFibGUgdG8gdGVsbCBpZiB3ZSBhcmUgaW4gRFQgY29udGV4dCBvdGhlcndpc2UgOihcbiAgICBpZiAoICgnZHQnID09PSBjb250ZXh0KSAmJiB0aGlzLmRldnRvb2xzICYmIChfdGFiSWQgPSB0aGlzLmRldnRvb2xzLmluc3BlY3RlZFdpbmRvdykgJiZcbiAgICAgICAgICgnbnVtYmVyJyA9PT0gdHlwZW9mKF90YWJJZCA9IF90YWJJZC50YWJJZCkpICkge1xuICAgICAgX3VwZGF0ZVRhYklkLmNhbGwodGhpcyk7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHRoaXMuY3JlYXRlTXNnT2JqZWN0KGNvbnRleHQpO1xufTtcblxuXG4vLyBzaW5nbGV0b24gcmVwcmVzZW50aW5nIHRoaXMgbW9kdWxlXG52YXIgc2luZ2xldG9uID0gbmV3IE1lc3NhZ2luZygpO1xuXG4vLyBoZWxwZXIgZnVuY3Rpb24gdG8gaW5zdGFsbCBtZXRob2RzIHVzZWQgZm9yIHVuaXQgdGVzdHNcbmZ1bmN0aW9uIGluc3RhbGxVbml0VGVzdE1ldGhvZHModGFyZ2V0LCBkZWxlZ2F0ZSkge1xuICAvLyBzZXR0ZXJzXG4gIHRhcmdldC5fX3NldFJ1bnRpbWUgPSBmdW5jdGlvbihydCkgeyBkZWxlZ2F0ZS5ydW50aW1lID0gcnQ7IHJldHVybiB0YXJnZXQ7IH07XG4gIHRhcmdldC5fX3NldERldlRvb2xzID0gZnVuY3Rpb24oZHQpIHsgZGVsZWdhdGUuZGV2dG9vbHMgPSBkdDsgcmV0dXJuIHRhcmdldDsgfTtcbiAgLy8gZ2V0dGVyc1xuICB0YXJnZXQuX19nZXRJZCA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gZGVsZWdhdGUuaWQ7IH07XG4gIHRhcmdldC5fX2dldFBvcnQgPSBmdW5jdGlvbigpIHsgcmV0dXJuIGRlbGVnYXRlLnBvcnQ7IH07XG4gIHRhcmdldC5fX2dldFBvcnRNYXAgPSBmdW5jdGlvbigpIHsgcmV0dXJuIGRlbGVnYXRlLnBvcnRNYXA7IH07XG4gIHRhcmdldC5fX2dldEhhbmRsZXJzID0gZnVuY3Rpb24oKSB7IHJldHVybiBkZWxlZ2F0ZS5oYW5kbGVyczsgfTtcbiAgdGFyZ2V0Ll9fZ2V0UGVuZGluZ1JlcXMgPSBmdW5jdGlvbigpIHsgcmV0dXJuIGRlbGVnYXRlLnBlbmRpbmdSZXFzOyB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgLy8gc2FtZSB0YWIgaWRcbiAgU0FNRV9UQUI6IFNBTUVfVEFCLFxuICAvLyBzZWUgZGVzY3JpcHRpb24gZm9yIGluaXQgZnVuY3Rpb24gYWJvdmVcbiAgaW5pdDogc2luZ2xldG9uLmluaXQuYmluZChzaW5nbGV0b24pLFxuICAvLyAtLS0gZm9yIHVuaXQgdGVzdHMgLS0tXG4gIC8vIGFsbG93IHVuaXQgdGVzdGluZyBvZiB0aGUgbWFpbiBtb2R1bGU6XG4gIF9fYWxsb3dVbml0VGVzdHM6IGZ1bmN0aW9uKCkgeyBpbnN0YWxsVW5pdFRlc3RNZXRob2RzKHRoaXMsIHNpbmdsZXRvbik7IH0sXG4gIC8vIGNvbnRleHQgY2xvbmluZ1xuICBfX2NyZWF0ZUNsb25lOiBmdW5jdGlvbigpIHtcbiAgICB2YXIgY2xvbmUgPSBuZXcgTWVzc2FnaW5nKCk7XG4gICAgY2xvbmUuU0FNRV9UQUIgPSBTQU1FX1RBQjtcbiAgICBpbnN0YWxsVW5pdFRlc3RNZXRob2RzKGNsb25lLCBjbG9uZSk7XG4gICAgcmV0dXJuIGNsb25lO1xuICB9XG59O1xuIl19
(1)
});
